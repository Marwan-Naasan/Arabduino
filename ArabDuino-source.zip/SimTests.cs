using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.IO;
using Arabduino;
class FakeBoard:IVirtualBoard {
 public int Writes,Servos,Prints;public double Analog=512;public bool High,Low;public Action Finish;
 public double Read(int pin,bool analog){return analog?Analog:0;}
 public void Write(int pin,double value,bool analog){Writes++;if(value>0)High=true;else Low=true;if(Writes>=8&&Finish!=null)Finish();}
 public void Mode(int pin,int mode){}
 public void Servo(int pin,double angle){Servos++;if(angle<0||angle>180)throw new Exception("Servo range");if(Servos>=8&&Finish!=null)Finish();}
 public void Print(string text){Prints++;}
}
class SimTests {
 static int count;
 static void Main(string[] args){Run().GetAwaiter().GetResult();Console.WriteLine("PASS: "+count+" simulator checks");if(args.Length>0){int n=0;foreach(var pair in Examples.All){string dir=Path.Combine(args[0],"example"+(n++));Directory.CreateDirectory(dir);File.WriteAllText(Path.Combine(dir,Path.GetFileName(dir)+".ino"),Translator.Convert(pair.Value),new System.Text.UTF8Encoding(false));File.WriteAllText(Path.Combine(dir,Path.GetFileName(dir)+".arabduino"),pair.Value,new System.Text.UTF8Encoding(false));}}}
 static async Task Run(){
  foreach(string name in new[]{"أساسيات • وميض المصباح","إدخال • زر يشغّل LED","تماثلي • مقاومة متغيرة وLED","تماثلي • تدرج السطوع PWM","مكتبة Servo • حركة سيرفو"}){
   var board=new FakeBoard();var vm=new VirtualMachine(board){Speed=1000};var cts=new CancellationTokenSource();cts.CancelAfter(5000);board.Finish=()=>cts.Cancel();try{await vm.Run(Examples.All[name],cts.Token);}catch(OperationCanceledException){}
   if(name.Contains("Servo")){if(board.Servos<2)throw new Exception("Servo did not run");}
   else if(board.Writes<2)throw new Exception("No virtual outputs: "+name);
   if(name.Contains("وميض")&&(!board.High||!board.Low))throw new Exception("Blink did not alternate");count++;
  }
  var f=new FakeBoard();var v=new VirtualMachine(f);var stop=new CancellationTokenSource(50);try{await v.Run("void setup(){} void loop(){ while(true){} }",stop.Token);}catch(OperationCanceledException){count++;}
  bool failed=false;try{await new VirtualMachine(f).Run("void setup(){ unknown(); } void loop(){}",CancellationToken.None);}catch(Exception ex){failed=ex.Message.Contains("unknown");}if(!failed)throw new Exception("Unsupported call silently accepted");count++;
 }
}
