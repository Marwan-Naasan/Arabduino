using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.IO;
using Arabduino;
class TestEditor:CodeEditor {public void Key(char c){base.OnKeyPress(new KeyPressEventArgs(c));}}
class TestCombo:BlockComboBox {public void Wheel(){var message=Message.Create(Handle,0x020A,new IntPtr(-120<<16),IntPtr.Zero);base.WndProc(ref message);}}
class EditorTests {
 static int count;
 static void Check(bool value,string name){if(!value)throw new Exception(name);count++;}
 static string Lex(string code){var tokens=Regex.Matches(Translator.Convert(code),@"//[^\r\n]*|/\*[\s\S]*?\*/|""(?:\\[\s\S]|[^""\\])*""|'(?:\\[\s\S]|[^'\\])*'|\w+|\S");return string.Join("|",tokens.Cast<Match>().Select(m=>m.Value).Where(t=>!t.StartsWith("//")&&!t.StartsWith("/*")));}
 [STAThread]static void Main(string[] args){
  Application.EnableVisualStyles();
  Check(CodeFormat.LatinDigits("١٢٣ ۴۵۶ 789")=="123 456 789","Latin number conversion");
  Check(CodeFormat.NormalizeNumbers("انتظار(١٢٣)؛ // ١\nتسلسلي.اطبع(\"١\")؛")=="انتظار(123)؛ // ١\nتسلسلي.اطبع(\"١\")؛","Normalize old code without changing strings or comments");
  Check(CodeFormat.EnterText("",0)=="\n","Enter in empty document");Check(CodeFormat.EnterText("فارغ إعداد() {",14).EndsWith("    "),"Brace indentation");
  Check(!Regex.IsMatch(Translator.Blink,@"[\u0660-\u0669\u06f0-\u06f9]"),"ASCII digits in blink");
  Check(CodeFormat.EnterText("// {",4)=="\n","Comment braces do not indent");
  string rawContent="void setup(){\nconst char* s=R\"tag(one\n    { two\nthree)tag\";\n}\n";string formatted=CodeFormat.Format(rawContent);Check(formatted.Contains("one\n    { two\nthree)tag"),"Formatter preserves raw string whitespace");
  int n=0;foreach(var pair in Examples.All){Check(!Regex.IsMatch(pair.Value,@"[\u0660-\u0669\u06f0-\u06f9]"),"ASCII digits: "+pair.Key);var doc=BlockDocument.Parse(pair.Value);Check(doc.Generate()==pair.Value,"Exact no-edit roundtrip: "+pair.Key);doc.Changed=true;string generated=doc.Generate();Check(Lex(generated)==Lex(pair.Value),"Edited block roundtrip: "+pair.Key);if(args.Length>0){string dir=Path.Combine(args[0],"blocks"+(n++));Directory.CreateDirectory(dir);File.WriteAllText(Path.Combine(dir,Path.GetFileName(dir)+".ino"),Translator.Convert(generated),new System.Text.UTF8Encoding(false));}}
  string custom="#include <Wire.h>\nstruct Item { int a; };\nconst char* message = R\"tag({ x; })tag\";\nvoid setup() { int values[] = {1, 2}; }\nvoid loop() { customCall(); }\n";var fallback=BlockDocument.Parse(custom);Check(fallback.Generate()==custom,"Unsupported C++ preserved exactly");fallback.Changed=true;Check(fallback.Generate().Contains("R\"tag({ x; })tag\""),"Raw literal preserved on editing");
  var blink=BlockDocument.Parse(Translator.Blink);var wait=blink.Nodes.First(x=>x.Kind=="loop").Children.First(x=>x.Kind=="delay");wait.A="250";blink.Changed=true;Check(blink.Generate().Contains("انتظار(250)"),"Block edit generates code");
  using(var box=new TestEditor()){
   var handle=box.Handle;box.Text="فارغ إعداد() {}";box.ResetHistory();int caret=box.Text.IndexOf('}') ;box.Select(caret,0);box.Key('\r');Check(box.Text.Contains("{\n    \n}"),"Enter expands brace pair");Check(box.SelectionStart==box.Text.IndexOf("    ")+4,"Caret stays inside indented pair");box.Undo();Check(box.Text=="فارغ إعداد() {}","Undo restores typing");box.Redo();Check(box.Text.Contains("{\n    \n}"),"Redo restores typing");
   box.Text="انتظار(1000)؛";box.ResetHistory();box.Select(4,3);string original=box.Text;Highlight.Paint(box);Check(box.Text==original&&box.SelectionStart==4&&box.SelectionLength==3,"Highlight preserves text and selection");box.SelectedText="ABC";string edited=box.Text;Highlight.Paint(box);box.Undo();Check(box.Text==original,"Undo ignores syntax formatting");box.Redo();Check(box.Text==edited,"Redo ignores syntax formatting");
   box.SetDirection(false);Check(box.Text==edited&&!box.RtlMode,"LTR is view-only");box.SetDirection(true);Check(box.Text==edited&&box.RtlMode,"RTL is view-only");
   box.Text="";box.ResetHistory();box.Key('(');Check(box.Text=="()"&&box.SelectionStart==1,"Parenthesis pair");box.Key(')');Check(box.Text=="()"&&box.SelectionStart==2,"Skip paired close");
   box.Text="فارغ إعداد(){\nانتظار(1000)؛\n}";string before=box.Text;box.Select(0,5);box.FormatCode();Check(Lex(before)==Lex(box.Text)&&box.Text.Contains("    انتظار"),"Formatting preserves selected code");
  }
  using(var view=new BlocksEditor()){view.LoadCode(Translator.Blink);var fields=All(view).OfType<TextBox>().Where(t=>t.Text=="1000").ToArray();Check(fields.Length==2,"Block value editors generated");fields[0].Text="250";Check(view.Document.Changed&&view.Document.Generate().Contains("انتظار(250)"),"Editing a block field changes generated text");view.Undo();Check(view.Document.Generate()==Translator.Blink,"Block undo restores exact previous source");view.Redo();Check(view.Document.Generate().Contains("انتظار(250)"),"Block redo restores value");view.LoadCode(view.Document.Generate());view.Undo();Check(view.Document.Generate()==Translator.Blink,"Tab reload retains block history");}
  using(var combo=new TestCombo()){combo.Items.AddRange(new object[]{"13","12","11"});combo.SelectedIndex=0;combo.Wheel();Check(combo.SelectedIndex==0,"Scrolling past block fields never changes pins");}
  Console.WriteLine("PASS: "+count+" RTL, editing and blocks checks");
 }
 static System.Collections.Generic.IEnumerable<Control> All(Control root){foreach(Control child in root.Controls){yield return child;foreach(var nested in All(child))yield return nested;}}
}
