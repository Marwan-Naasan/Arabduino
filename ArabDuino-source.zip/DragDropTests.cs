using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using System.Collections.Generic;
using Arabduino;
class DragDropTests {
 static int count;static void Check(bool pass,string name){if(!pass)throw new Exception(name);count++;}
 static IEnumerable<Control> All(Control root){foreach(Control c in root.Controls){yield return c;foreach(var nested in All(c))yield return nested;}}
 static void Event(Control c,string name,DragEventArgs args){typeof(Control).GetMethod(name,BindingFlags.Instance|BindingFlags.NonPublic).Invoke(c,new object[]{args});}
 [STAThread]static void Main(string[] args){
  Check(CoreReferenceAudit.Functions.Length==56,"Official core function count");foreach(string name in CoreReferenceAudit.Functions){var entry=ReferenceCatalog.All.First(e=>e.Key==name);Check(Translator.Convert(entry.Arabic)==name,"Audited core alias: "+name);}
  Check(CoreReferenceAudit.Report().Contains("56 / 56"),"Complete core coverage report");Check(Translator.Convert("حوّل_صحيح(3.5)")=="int(3.5)","Functional int cast alias");Check(Translator.Convert("حوّل_طويل_موجب(5)")=="(unsigned long)(5)","Unsigned cast syntax");
  using(var editor=new BlocksEditor()){editor.LoadCode("فارغ إعداد() {}\nفارغ تكرار() {}\n");var doc=editor.Document;var loop=doc.Nodes.First(n=>n.Kind=="loop");Check(!editor.InsertBlock("loop",doc.Nodes,0),"Duplicate root rejected");Check(!editor.InsertBlock("delay",doc.Nodes,0),"Commands cannot snap at top-level");Check(editor.InsertBlock("ifelse",loop.Children,0),"Conditional container inserted");var branch=loop.Children[0];Check(editor.InsertBlock("digital",branch.Children,0),"Block nested in if branch");Check(editor.InsertBlock("delay",branch.OtherChildren,0),"Block nested in else branch");Check(!editor.MoveBlock(branch,loop.Children,branch.Children,0),"Cyclic self nesting rejected");Check(!editor.MoveBlock(doc.Nodes[0],doc.Nodes,branch.Children,0),"Setup stays at script root");var nested=branch.Children[0];Check(editor.MoveBlock(nested,branch.Children,branch.OtherChildren,1),"Nested block moves between branches");Check(editor.Document.Generate().Contains("وإلا"),"If/else code generated together");
   var zone=All(editor).OfType<SnapZone>().First(z=>object.ReferenceEquals(z.Tag,loop.Children));var data=new DataObject();data.SetData("Arabduino.Kind","delay");var point=zone.PointToScreen(new Point(3,3));var drag=new DragEventArgs(data,0,point.X,point.Y,DragDropEffects.Copy|DragDropEffects.Move,DragDropEffects.None);Event(zone,"OnDragEnter",drag);Check(drag.Effect==DragDropEffects.Copy&&zone.Highlighted,"Actual drag-enter highlights valid insertion slot");int before=loop.Children.Count;Event(zone,"OnDragDrop",drag);Check(loop.Children.Count==before+1,"Actual drop event inserts block");editor.Undo();Check(editor.Document.Nodes.First(n=>n.Kind=="loop").Children.Count==before,"Drag insertion can be undone");
  }
  Check(FutureTheme.Background.GetBrightness()<0.1&&FutureTheme.Text.GetBrightness()>0.8,"Dark surface and readable text");
  if(args.Length>0){Directory.CreateDirectory(args[0]);string path=Path.Combine(args[0],"reference-smoke");Directory.CreateDirectory(path);File.WriteAllText(Path.Combine(path,"reference-smoke.ino"),Translator.Convert(CoreReferenceAudit.UnoSmoke),new System.Text.UTF8Encoding(false));File.WriteAllText(Path.Combine(args[0],"REFERENCE-COVERAGE.txt"),CoreReferenceAudit.Report(),System.Text.Encoding.UTF8);}
  Console.WriteLine("PASS: "+count+" Arduino audit, drag/drop and theme checks");
 }
}
