// ثبّت مكتبة LiquidCrystal. وصل نموذج LCD 1602 في المحاكي بتوصيلات هذا المثال.
#include <LiquidCrystal.h>
LiquidCrystal arabduino_id_0634062706340629(12, 11, 5, 4, 3, 2);
void setup() {
    arabduino_id_0634062706340629.begin(16, 2);
    arabduino_id_0634062706340629.print("Hello Arabduino");
}
void loop() { }
