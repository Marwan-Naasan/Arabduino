void setup() { pinMode(8, OUTPUT); }
void loop() { tone(8, 440, 300); delay(600); tone(8, 660, 300); delay(600); noTone(8); }
