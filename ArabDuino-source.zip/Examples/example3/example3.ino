// LED مع مقاومة على D9
int arabduino_id_0633063706480639 = 0;
int arabduino_id_062e063706480629 = 5;
void setup() { pinMode(9, OUTPUT); }
void loop() {
    analogWrite(9, arabduino_id_0633063706480639);
    arabduino_id_0633063706480639 = arabduino_id_0633063706480639 + arabduino_id_062e063706480629;
    if (arabduino_id_0633063706480639 <= 0 or arabduino_id_0633063706480639 >= 255) { arabduino_id_062e063706480629 = -arabduino_id_062e063706480629; }
    delay(30);
}
