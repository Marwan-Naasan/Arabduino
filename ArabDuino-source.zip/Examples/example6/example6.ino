// EEPROM تأتي مع حزمة AVR. المثال للوحة الحقيقية.
#include <EEPROM.h>
void setup() {
    Serial.begin(9600);
    byte arabduino_id_0642064a06450629 = EEPROM.read(0);
    Serial.println(arabduino_id_0642064a06450629);
    EEPROM.update(0, arabduino_id_0642064a06450629 + 1);
}
void loop() { }
