// ثبّت مكتبة Servo. إشارة السيرفو D9 والتغذية 5V والأرضي GND.
#include <Servo.h>
Servo arabduino_id_0645062d06310643;
void setup() { arabduino_id_0645062d06310643.attach(9); }
void loop() {
    for (int arabduino_id_063206270648064a0629 = 0; arabduino_id_063206270648064a0629 <= 180; arabduino_id_063206270648064a0629++) {
        arabduino_id_0645062d06310643.write(arabduino_id_063206270648064a0629);
        delay(15);
    }
    for (int arabduino_id_063206270648064a0629 = 180; arabduino_id_063206270648064a0629 >= 0; arabduino_id_063206270648064a0629--) {
        arabduino_id_0645062d06310643.write(arabduino_id_063206270648064a0629);
        delay(15);
    }
}
