// Wire تأتي مع حزمة AVR. المثال للوحة الحقيقية.
#include <Wire.h>
void setup() {
    Serial.begin(9600);
    Wire.begin();
    for (byte arabduino_id_06390646064806270646 = 1; arabduino_id_06390646064806270646 < 127; arabduino_id_06390646064806270646++) {
        Wire.beginTransmission(arabduino_id_06390646064806270646);
        if (Wire.endTransmission() == 0) { Serial.println(arabduino_id_06390646064806270646); }
    }
}
void loop() { }
