void setup() { pinMode(9, OUTPUT); }
void loop() { for (int arabduino_id_0633063106390629 = 0; arabduino_id_0633063106390629 <= 255; arabduino_id_0633063106390629 += 5) { analogWrite(9, arabduino_id_0633063106390629); delay(40); } }
