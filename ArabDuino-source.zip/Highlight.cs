using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Collections.Generic;
namespace Arabduino {
public static class Highlight {
 [StructLayout(LayoutKind.Sequential)] struct Point {public int X,Y;}
 [DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr h,int m,IntPtr w,IntPtr l);
 [DllImport("user32.dll",EntryPoint="SendMessage")] static extern IntPtr ScrollMessage(IntPtr h,int m,IntPtr w,ref Point p);
 static HashSet<string> types=new HashSet<string>(new[]{"void","int","long","short","float","double","char","String","bool","byte","unsigned","const","static","volatile","class","struct","public","private"});
 static HashSet<string> flow=new HashSet<string>(new[]{"if","else","for","while","do","return","break","continue","switch","case","default","true","false","and","or","not"});
 static Regex tokens=new Regex(@"(?<comment>//[^\r\n]*|/\*[\s\S]*?(?:\*/|$))|(?<str>""(?:\\[\s\S]|[^""\\])*""|'(?:\\[\s\S]|[^'\\])*')|(?<pre>^\s*#[^\r\n]*)|(?<number>\b\d+(?:\.\d+)?\b)|(?<word>[\p{L}_][\p{L}\p{Mn}\p{Nd}_]*)",RegexOptions.Multiline|RegexOptions.Compiled);
 public static void Paint(RichTextBox box){
  if(box.TextLength>200000)return;var editor=box as CodeEditor;if(editor!=null)editor.Styling=true;bool modified=box.Modified;int start=box.SelectionStart,length=box.SelectionLength;Point scroll=new Point();ScrollMessage(box.Handle,0x04DD,IntPtr.Zero,ref scroll);SendMessage(box.Handle,0x000B,IntPtr.Zero,IntPtr.Zero);
  bool dark=box.BackColor.GetBrightness()<0.4;try{box.SelectAll();box.SelectionColor=dark?FutureTheme.Text:Color.FromArgb(35,49,60);foreach(Match m in tokens.Matches(box.Text)) {Color color=dark?FutureTheme.Text:Color.FromArgb(35,49,60);if(m.Groups["comment"].Success)color=dark?FutureTheme.Muted:Color.FromArgb(112,127,139);else if(m.Groups["str"].Success)color=dark?Color.FromArgb(249,196,112):Color.FromArgb(158,74,33);else if(m.Groups["pre"].Success)color=dark?FutureTheme.Purple:Color.FromArgb(112,73,160);else if(m.Groups["number"].Success)color=dark?FutureTheme.Purple:Color.FromArgb(40,100,181);else {string word=m.Value,v;if(Translator.Words.TryGetValue(word,out v))word=v;if(types.Contains(word))color=dark?FutureTheme.Cyan:Color.FromArgb(0,125,128);else if(flow.Contains(word))color=dark?FutureTheme.Purple:Color.FromArgb(150,73,170);else if(Translator.Words.ContainsValue(word))color=dark?Color.FromArgb(108,192,255):Color.FromArgb(199,103,0);}box.Select(m.Index,m.Length);box.SelectionColor=color;}}
  finally{box.Select(start,length);box.Modified=modified;ScrollMessage(box.Handle,0x04DE,IntPtr.Zero,ref scroll);SendMessage(box.Handle,0x000B,new IntPtr(1),IntPtr.Zero);box.Invalidate();if(editor!=null)editor.Styling=false;}
 }
}
public static class Examples {
 static Examples(){foreach(var entry in AdvancedExamples.All)All[entry.Key]=entry.Value;}
 public static readonly Dictionary<string,string> All=new Dictionary<string,string>{
 {"أساسيات • وميض المصباح",Translator.Blink},
 {"إدخال • زر يشغّل LED","// صِل الزر بين D2 و GND. وLED بين D13 ومقاومة ثم GND.\nفارغ إعداد() {\n    نمط_المنفذ(2، دخل_سحب)؛\n    نمط_المنفذ(13، خرج)؛\n}\nفارغ تكرار() {\n    إذا (قراءة_رقمية(2) == منخفض) {\n        إشارة_رقمية(13، مرتفع)؛\n    } وإلا {\n        إشارة_رقمية(13، منخفض)؛\n    }\n    انتظار(20)؛\n}\n"},
 {"تماثلي • مقاومة متغيرة وLED","// خرج المقاومة المتغيرة إلى A0. وLED مع مقاومة على D9.\nفارغ إعداد() {\n    نمط_المنفذ(9، خرج)؛\n    تسلسلي.ابدأ(9600)؛\n}\nفارغ تكرار() {\n    صحيح قراءة = قراءة_تماثلية(A0)؛\n    صحيح سطوع = تحويل_مدى(قراءة، 0، 1023، 0، 255)؛\n    إشارة_تماثلية(9، سطوع)؛\n    تسلسلي.اطبع_سطر(قراءة)؛\n    انتظار(50)؛\n}\n"},
 {"تماثلي • تدرج السطوع PWM","// LED مع مقاومة على D9\nصحيح سطوع = 0؛\nصحيح خطوة = 5؛\nفارغ إعداد() { نمط_المنفذ(9، خرج)؛ }\nفارغ تكرار() {\n    إشارة_تماثلية(9، سطوع)؛\n    سطوع = سطوع + خطوة؛\n    إذا (سطوع <= 0 أو سطوع >= 255) { خطوة = -خطوة؛ }\n    انتظار(30)؛\n}\n"},
 {"مكتبة Servo • حركة سيرفو","// ثبّت مكتبة Servo. إشارة السيرفو D9 والتغذية 5V والأرضي GND.\n#تضمين <Servo.h>\nسيرفو محرك؛\nفارغ إعداد() { محرك.اربط(9)؛ }\nفارغ تكرار() {\n    لكل (صحيح زاوية = 0؛ زاوية <= 180؛ زاوية++) {\n        محرك.اكتب(زاوية)؛\n        انتظار(15)؛\n    }\n    لكل (صحيح زاوية = 180؛ زاوية >= 0؛ زاوية--) {\n        محرك.اكتب(زاوية)؛\n        انتظار(15)؛\n    }\n}\n"},
 {"مكتبة LiquidCrystal • شاشة LCD","// ثبّت مكتبة LiquidCrystal. وصل نموذج LCD 1602 في المحاكي بتوصيلات هذا المثال.\n#تضمين <LiquidCrystal.h>\nشاشة_بلورية شاشة(12، 11، 5، 4، 3، 2)؛\nفارغ إعداد() {\n    شاشة.ابدأ(16، 2)؛\n    شاشة.اطبع(\"Hello Arabduino\")؛\n}\nفارغ تكرار() { }\n"},
 {"مكتبة EEPROM • ذاكرة دائمة","// EEPROM تأتي مع حزمة AVR. المثال للوحة الحقيقية.\n#تضمين <EEPROM.h>\nفارغ إعداد() {\n    تسلسلي.ابدأ(9600)؛\n    بايت قيمة = ذاكرة.اقرأ(0)؛\n    تسلسلي.اطبع_سطر(قيمة)؛\n    ذاكرة.حدّث(0، قيمة + 1)؛\n}\nفارغ تكرار() { }\n"},
 {"مكتبة Wire • فحص I2C","// Wire تأتي مع حزمة AVR. المثال للوحة الحقيقية.\n#تضمين <Wire.h>\nفارغ إعداد() {\n    تسلسلي.ابدأ(9600)؛\n    ناقل_سلكي.ابدأ()؛\n    لكل (بايت عنوان = 1؛ عنوان < 127؛ عنوان++) {\n        ناقل_سلكي.ابدأ_إرسال(عنوان)؛\n        إذا (ناقل_سلكي.أنه_إرسال() == 0) { تسلسلي.اطبع_سطر(عنوان)؛ }\n    }\n}\nفارغ تكرار() { }\n"}
 };
}
}
