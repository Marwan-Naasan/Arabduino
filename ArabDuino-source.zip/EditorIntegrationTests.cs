using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using Arabduino;
class EditorIntegrationTests {
 static int count;static void Check(bool value,string name){if(!value)throw new Exception(name);count++;}
 static object Field(Editor e,string name){return typeof(Editor).GetField(name,BindingFlags.Instance|BindingFlags.NonPublic).GetValue(e);}
 static object Call(Editor e,string name,params object[] args){return typeof(Editor).GetMethod(name,BindingFlags.Instance|BindingFlags.NonPublic).Invoke(e,args);}
 [STAThread]static void Main(){
  Environment.SetEnvironmentVariable("ARABDUINO_DATA_DIR",Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"qa-integration-data"));
  Application.EnableVisualStyles();using(var editor=new Editor()){
   editor.Show();editor.Hide();var handle=editor.Handle;var code=(CodeEditor)Field(editor,"code");var modes=(TabControl)Field(editor,"modes");var blocks=(BlocksEditor)Field(editor,"blocks");modes.CreateControl();code.CreateControl();
   string original=code.Text;modes.SelectedTab=(TabPage)Field(editor,"blocksPage");Check(blocks.Document!=null,"Switch to blocks imports text");modes.SelectedTab=(TabPage)Field(editor,"textPage");Check(code.Text==original,"Unchanged tab switch is exact");
   modes.SelectedTab=(TabPage)Field(editor,"blocksPage");var loop=blocks.Document.Nodes.First(n=>n.Kind=="loop");loop.Children.First(n=>n.Kind=="delay").A="250";blocks.Document.Changed=true;
   string source=(string)Call(editor,"CurrentSource");Check(source.Contains("انتظار(250)"),"Compile/simulate source syncs active blocks");modes.SelectedTab=(TabPage)Field(editor,"textPage");Check(code.Text==source,"Text tab receives block edits");
   code.Text="فارغ إعداد() {}\nفارغ تكرار() { انتظار(50)؛ }\n";string changed=code.Text;Call(editor,"CurrentSource");Check(code.Text==changed,"Old blocks never overwrite edited text");
   modes.SelectedTab=(TabPage)Field(editor,"blocksPage");loop=blocks.Document.Nodes.First(n=>n.Kind=="loop");loop.Children.First(n=>n.Kind=="delay").A="75";blocks.Document.Changed=true;
   string target=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"qa-integration-data","saved.arabduino");Directory.CreateDirectory(Path.GetDirectoryName(target));typeof(Editor).GetField("currentFile",BindingFlags.Instance|BindingFlags.NonPublic).SetValue(editor,target);Check((bool)Call(editor,"Save",false),"Save from blocks succeeds");Check(File.ReadAllText(target).Contains("انتظار(75)"),"Save includes latest block value");
  }
  Console.WriteLine("PASS: "+count+" code/blocks integration checks");
 }
}
