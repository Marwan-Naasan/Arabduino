$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
$compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if(!(Test-Path $compiler)){throw '.NET Framework compiler not found'}
if(!(Test-Path 'bundle\arduino-cli.exe')){
 New-Item -ItemType Directory -Force bundle | Out-Null
 Invoke-WebRequest 'https://github.com/arduino/arduino-cli/releases/download/v1.5.1/arduino-cli_1.5.1_Windows_64bit.zip' -OutFile cli.zip
 if((Get-FileHash cli.zip).Hash -ne 'FABE42E0EB04D00E776A66178299FF95A46C623DBC260F997E58FD514853DD40'){throw 'CLI checksum mismatch'}
 Expand-Archive cli.zip bundle -Force
}
& .\Generate-Aliases.ps1
$sources=@(Get-ChildItem -File -Filter '*.cs' | Where-Object {$_.Name -notmatch 'Tests\.cs$|^Installer\.cs$'} | Select-Object -ExpandProperty Name)
& $compiler /nologo /codepage:65001 /target:winexe /win32icon:arabduino.ico /out:Arabduino.exe /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Runtime.Serialization.dll /resource:ReferenceData.txt,refData /resource:ReferenceSources.txt,refSources @sources
if($LASTEXITCODE){throw 'Editor build failed'}
foreach($test in @('Tests','SimTests','CircuitTests','EditorTests','EditorIntegrationTests','UpgradeTests','DragDropTests','GlassTests')){
 if(!(Test-Path ($test+'.cs'))){continue}
 & $compiler /nologo /codepage:65001 ('/out:'+$test+'.exe') /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Runtime.Serialization.dll /reference:Arabduino.exe ($test+'.cs')
 if($LASTEXITCODE){throw ($test+' build failed')}
 & (Join-Path $PSScriptRoot ($test+'.exe'))
 if($LASTEXITCODE){throw ($test+' failed')}
}
& $compiler /nologo /codepage:65001 /target:winexe /win32icon:arabduino.ico /out:Arabduino-Setup-1.5.0.exe /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /resource:Arabduino.exe,app /resource:bundle\arduino-cli.exe,cli /resource:bundle\LICENSE.txt,cliLicense /resource:LICENSE.txt,license /resource:README.txt,guide /resource:arabduino.ico,icon /resource:Reference-CC-BY-SA-3.0.txt,referenceLicense Installer.cs AssemblyInfo.cs
if($LASTEXITCODE){throw 'Installer build failed'}
Write-Host 'Built Arabduino-Setup-1.5.0.exe'
