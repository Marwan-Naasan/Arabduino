$ErrorActionPreference='Stop'
$rows=[IO.File]::ReadAllLines((Join-Path $PSScriptRoot 'ReferenceData.txt'))
$mapping=@{}
foreach($row in $rows){
 if(!$row.Trim()){continue}
 $parts=$row.Split([char]0x00A7);if($parts.Count -ne 9){throw ('Invalid reference row: '+$parts[0])}
 $key=$parts[0];$arabic=$parts[1]
 if($key -in @('scope','array','arithmetic','comparison','logical','bitwise','increment','compoundAddition','dereference','semicolon','curlyBraces','singleLineComment','blockComment')){continue}
 if($arabic -notmatch '^[\p{L}\p{Mn}_][\p{L}\p{Mn}\p{Nd}_]*$'){continue}
 $canonical=($key -split '\.')[-1]
 if($key -eq 'doWhile'){$canonical='do'}
 if($key -eq 'switchCase'){$canonical='switch'}
 if($key -eq 'ledbuiltin'){$canonical='LED_BUILTIN'}
 if($key -eq 'stream'){$canonical='Stream'}
 if($key -eq 'SPI.SPISettings'){$canonical='SPISettings'}
 if($key -match '^(byte|char|int|long|float)Cast$'){$canonical=$Matches[1]}
 if($key -eq 'wordcast'){$canonical='word'}
 if($key -eq 'unsignedIntCast'){$canonical='(unsigned int)'}
 if($key -eq 'unsignedLongCast'){$canonical='(unsigned long)'}
 if($mapping.ContainsKey($arabic) -and $mapping[$arabic] -ne $canonical){throw ('Alias collision: '+$arabic)}
 $mapping[$arabic]=$canonical
}
$text=New-Object Text.StringBuilder
[void]$text.AppendLine('using System.Collections.Generic; namespace Arabduino { public static class ExpandedAliases { public static void Apply(Dictionary<string,string> words) {')
foreach($key in ($mapping.Keys | Sort-Object)){
 [void]$text.AppendLine(('words["'+$key+'"]="'+$mapping[$key]+'";'))
}
[void]$text.AppendLine('} } }')
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'ExpandedAliases.cs'),$text.ToString(),(New-Object Text.UTF8Encoding($false)))
Write-Host ('Generated '+$mapping.Count+' reference aliases')
