using System;
using System.Drawing;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using Arabduino;
class ExtendedFake:IVirtualBoard,IVirtualFeatures {
 public Action End;public int Calls;public string Printed="";public int Displays;
 void Tick(){if(++Calls>=10&&End!=null)End();}
 public double Read(int pin,bool analog){return 500;}public void Write(int p,double v,bool a){Tick();}public void Mode(int p,int m){}public void Servo(int p,double a){Tick();}public void Print(string t){Printed+=t;Tick();}public void Tone(int p,double f,double d){Tick();}public double Pulse(int p,double v,double t){Tick();return 5800;}public double Dht(int p,bool temp){Tick();return temp?24:50;}public void Lcd(int[] pins,string c,double[] a,string text){if(pins.Length!=6)throw new Exception("LCD mapping");Displays++;Tick();}
}
class UpgradeTests {
 static int count;static void Check(bool value,string name){if(!value)throw new Exception(name);count++;}
 static Circuit Model(Simulator s){return (Circuit)typeof(Simulator).GetField("circuit",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(s);}
 static void Link(Circuit c,string a,string b){c.Wires.Add(new Wire(){A=a,B=b});}
 static Part Add(Circuit c,string id,string kind){var d=PartCatalog.Get(kind);var p=new Part(){Id=id,Kind=kind,X=450,Y=120,Value=d.Default,Secondary=50};c.Parts.Add(p);return p;}
 static void Power(Circuit c,string id){Link(c,id+".5V","board.5V");Link(c,id+".GND","board.GND");}
 [STAThread]static void Main(){
  Check(ReferenceCatalog.All.Count>=218,"Reference count");foreach(var entry in ReferenceCatalog.All){Check(!string.IsNullOrWhiteSpace(entry.Parameters)&&!string.IsNullOrWhiteSpace(entry.Returns)&&entry.Source.StartsWith("https://github.com/"),"Source and detail: "+entry.Key);}
  Check(ReferenceCatalog.Find("إشارة_رقمية").Key=="digitalWrite","Arabic reference lookup");Check(ReferenceCatalog.Find("اختر").Key=="switchCase","Control reference lookup");Check(ReferenceCatalog.Find("تسلسلي.اطبع").Key=="Serial.print","Method reference lookup");Check(ReferenceCatalog.Find("مجهول.اكتب")==null,"Unknown object is not incorrectly identified as Serial");Check(ReferenceCatalog.Find("Serial.readStringUntil").Snippet.Contains("'\\n'"),"Snippet escape preservation");Check(ReferenceCatalog.ExplainCode("صحيح سطوع = 128؛ إشارة_تماثلية(9، سطوع)؛").Contains("128"),"Variable explanation contains declared initial value");
  Check(ReferenceCatalog.Resolve("محرك.اكتب","سيرفو محرك؛").Key=="Servo.write","Contextual Servo explanation");Check(ReferenceCatalog.Resolve("رسالة.طول_النص","نصي رسالة = \"abc\"؛").Key=="String.length","Contextual String explanation");
  var c=new Circuit();var bread=Add(c,"b","بريدبورد");var graph=new CircuitGraph(c);Check(graph.Connected("b.A1").Contains("b.E1"),"Breadboard five-hole group");Check(!graph.Connected("b.E1").Contains("b.F1"),"Breadboard center gap");Check(!graph.Connected("b.A1").Contains("b.A2"),"Adjacent columns isolated");Check(graph.Connected("b.P1").Contains("b.P30"),"Power rail continuous");Check(!graph.Connected("b.P1").Contains("b.N1")&&!graph.Connected("b.P1").Contains("b.Q1"),"Power rails independent");
  foreach(var def in PartCatalog.All){var p=new Part(){Id="x",Kind=def.Name};Check(PartCatalog.Pins(p).Count==p.Pins.Length,"Catalog pins: "+def.Name);for(int rotation=0;rotation<4;rotation++){p.Rotation=rotation;var size=PartCatalog.Size(p);Check(PartCatalog.Pins(p).Values.All(pt=>pt.X>=p.X&&pt.Y>=p.Y&&pt.X<=p.X+size.Width&&pt.Y<=p.Y+size.Height),"Rotated pin bounds: "+def.Name);}}
  Check(PartCatalog.All.Count==27&&PartCatalog.All.Count(d=>d.Simulated)==24,"Explicit simulator support badges");
  bool rejected=false;var bad=new Circuit();bad.Wires.Add(new Wire(){A="board.D99",B="board.GND"});try{Simulator.Deserialize(Simulator.Serialize(bad));}catch{rejected=true;}Check(rejected,"Unknown circuit endpoints rejected");var extreme=new Circuit();Add(extreme,"temp","DHT22").Value=9999;Check(Simulator.Deserialize(Simulator.Serialize(extreme)).Parts[0].Value==80,"Loaded sensor values constrained");
  using(var sim=new Simulator(()=>Translator.Blink,s=>{}))using(var bitmap=new Bitmap(1000,650))using(var g=Graphics.FromImage(bitmap)){
   c=Model(sim);c.Parts.Clear();c.Wires.Clear();bread=Add(c,"bread","بريدبورد");var led=Add(c,"led","LED");Link(c,"board.D13","bread.A1");Link(c,"bread.E1","led.+");Link(c,"led.-","board.GND");sim.Write(13,1,false);sim.Draw(g,new Rectangle(0,0,1000,650));Check(led.Level==1,"LED driven through breadboard group");c.Wires[1].A="bread.F1";sim.Draw(g,new Rectangle(0,0,1000,650));Check(led.Level==0,"Center gap prevents LED signal");
   c.Parts.Clear();c.Wires.Clear();var rgb=Add(c,"rgb","LED RGB");Link(c,"rgb.GND","board.GND");Link(c,"rgb.R","board.D9");sim.Write(9,255,true);sim.Draw(g,new Rectangle(0,0,1000,650));Check(rgb.Channels[0]==1&&rgb.Channels[1]==0,"RGB channels independent");
   c.Parts.Clear();c.Wires.Clear();var lcd=Add(c,"lcd","LCD 1602");Power(c,"lcd");Link(c,"lcd.RW","board.GND");string[] names={"RS","E","D4","D5","D6","D7"};int[] pins={12,11,5,4,3,2};for(int i=0;i<6;i++)Link(c,"lcd."+names[i],"board.D"+pins[i]);sim.Lcd(pins,"begin",new double[]{16,2},null);sim.Lcd(pins,"print",new double[0],"Hello");Check(lcd.DisplayLines[0].StartsWith("Hello"),"Powered LCD prints");sim.Lcd(pins,"setCursor",new double[]{0,1},null);sim.Lcd(pins,"print",new double[0],"42");Check(lcd.DisplayLines[1].StartsWith("42"),"LCD cursor selects second row");sim.Lcd(pins,"clear",new double[0],null);Check(lcd.DisplayLines.All(row=>row.Length==0),"LCD clear");
   c.Parts.Clear();c.Wires.Clear();var dht=Add(c,"dht","DHT22");dht.Value=31;dht.Secondary=65;Power(c,"dht");Link(c,"dht.DATA","board.D2");Check(sim.Dht(2,true)==31&&sim.Dht(2,false)==65,"DHT values follow properties");c.Wires.RemoveAll(w=>w.A=="dht.5V");Check(double.IsNaN(sim.Dht(2,true)),"Unpowered DHT does not produce valid measurement");
   c.Parts.Clear();c.Wires.Clear();var range=Add(c,"ranger","HC-SR04");range.Value=100;Power(c,"ranger");Link(c,"ranger.TRIG","board.D2");Link(c,"ranger.ECHO","board.D3");Check(sim.Pulse(3,1,30000)==0,"No echo without trigger");sim.Write(2,1,false);sim.Write(2,0,false);Check(sim.Pulse(3,1,30000)==5800,"Range converts centimeters to echo duration");sim.Write(2,1,false);Check(sim.Pulse(3,1,100)==0,"Pulse timeout");
   c.Parts.Clear();c.Wires.Clear();var relay=Add(c,"relay","ريليه");led=Add(c,"led","LED");Power(c,"relay");Link(c,"relay.IN","board.D7");Link(c,"relay.COM","board.5V");Link(c,"relay.NO","led.+");Link(c,"led.-","board.GND");sim.Write(7,1,false);sim.Draw(g,new Rectangle(0,0,1000,650));Check(relay.Active&&led.Level==1,"Relay NO drives load");sim.Write(7,0,false);sim.Draw(g,new Rectangle(0,0,1000,650));Check(!relay.Active&&led.Level==0,"Relay opens load");
   c.Wires[0].ColorArgb=Color.Purple.ToArgb();c.Wires[0].Bends.Add(new CircuitPoint(new Point(123,456)));var restored=Simulator.Deserialize(Simulator.Serialize(c));Check(restored.Wires[0].ColorArgb==Color.Purple.ToArgb()&&restored.Wires[0].Bends[0].X==123,"Wire colors and routes saved");
  }
  SynchronizationContext.SetSynchronizationContext(null);
  foreach(string name in new[]{"صفارة ونغمة","حساس مسافة HC-SR04","حرارة ورطوبة DHT22","شاشة LCD 1602"}){var fake=new ExtendedFake();var stop=new CancellationTokenSource(5000);fake.End=()=>stop.Cancel();try{new VirtualMachine(fake){Speed=10000}.Run(AdvancedExamples.All[name],stop.Token).GetAwaiter().GetResult();}catch(OperationCanceledException){}Check(fake.Calls>=10,"Extended interpreter execution: "+name);if(name.Contains("LCD"))Check(fake.Displays>=3,"LCD driver API");}
  Console.WriteLine("PASS: "+count+" learning, components and advanced simulation checks");
 }
}
