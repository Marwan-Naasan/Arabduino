﻿# Sources used for Arabduino 1.5

Reviewed on 2026-10-29. Arabic articles are authored educational adaptations, not an official Arduino translation.

- Arduino Language Reference: https://docs.arduino.cc/language-reference/
- Official editable reference: https://github.com/arduino/reference-en
- Servo API: https://github.com/arduino-libraries/Servo/blob/master/docs/api.md
- LiquidCrystal API: https://github.com/arduino-libraries/LiquidCrystal/blob/master/docs/api.md
- Adafruit DHT implementation: https://github.com/adafruit/DHT-sensor-library/blob/master/DHT.cpp
- EEPROM guide: https://github.com/arduino/docs-content/blob/main/content/learn/07.built-in-libraries/03.eeprom/eeprom.md

ReferenceData.txt contains 218 Arabic articles, each with syntax, parameters, return information, cautions, and a snippet. ReferenceSources.txt maps article keys to actual upstream source files. Generate-Aliases.ps1 derives compiler aliases from the data while excluding prose-only concepts and operators that are not C++ identifiers.

Arabic learning material adapted from the Arduino reference is distributed under Creative Commons Attribution-ShareAlike 3.0. Attribution belongs to Arduino and the reference contributors, with Arabduino contributors responsible for the Arabic adaptation. The full upstream license is Reference-CC-BY-SA-3.0.txt. Original application code remains MIT. The Adafruit and library links document the respective APIs; no library binaries or Wokwi assets are embedded by this change.

Wokwi was studied as a workflow reference, using its public documentation:

- https://docs.wokwi.com/guides/diagram-editor
- https://docs.wokwi.com/getting-started/supported-hardware
- https://docs.wokwi.com/parts/wokwi-hc-sr04
- https://docs.wokwi.com/parts/wokwi-dht22

Ideas implemented independently: component search and categories, properties, rotatable parts, zoom/pan/fit, colored routed wires, circuit undo/redo, and library-level virtual sensor/display models. No Wokwi implementation or artwork was copied. The simulator is a limited interpreter and logical circuit model, not Wokwi, an AVR emulator, or an electrical solver. Breadboard groups and rails are actual graph connections; preview-only parts are explicitly marked and have no electrical behavior.

Scratch interaction research, reviewed 2026-10-30:
- https://scratch.mit.edu/help/studio/tips/howto/get-started-1/
- https://scratch.mit.edu/help/studio/tips/blocks/repeat/
- https://scratchfoundation.org/learn/learning-library
Independent implementation in C#/Windows Forms: drag a palette item into a script,
move nested statements, snap into a repeat/condition body, and drop reporter values
into fields. No Scratch code, trademarks or artwork are embedded.
CoreReferenceAudit.cs enumerates all 56 core functions from the official index.
The Uno smoke sketch exercises supported APIs with official Wire/SPI headers.

Version 1.4 uses the user's two Scratch screenshots as visual references only.
Command connectors, C-shaped bodies, oval reporters and hexagonal conditions
are independently drawn with GraphicsPath. The labels and Arduino vocabulary
are Arabduino-specific. Glass styling is custom gradient rendering; it does
not embed Apple Liquid Glass assets or claim native OS material support.
