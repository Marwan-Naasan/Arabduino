using System;
using System.Collections.Generic;
using System.Linq;
namespace Arabduino {
public static class AdvancedExamples {
 public static readonly Dictionary<string,string> All=new Dictionary<string,string>{
 {"بريدبورد وLED",Translator.Blink},
 {"ألوان RGB","فارغ إعداد() { نمط_المنفذ(9، خرج)؛ نمط_المنفذ(10، خرج)؛ نمط_المنفذ(11، خرج)؛ }\nفارغ تكرار() {\n    إشارة_تماثلية(9، 255)؛ إشارة_تماثلية(10، 0)؛ إشارة_تماثلية(11، 0)؛ انتظار(700)؛\n    إشارة_تماثلية(9، 0)؛ إشارة_تماثلية(10، 255)؛ انتظار(700)؛\n    إشارة_تماثلية(10، 0)؛ إشارة_تماثلية(11، 255)؛ انتظار(700)؛\n}\n"},
 {"صفارة ونغمة","فارغ إعداد() { نمط_المنفذ(8، خرج)؛ }\nفارغ تكرار() { نغمة(8، 440، 300)؛ انتظار(600)؛ نغمة(8، 660، 300)؛ انتظار(600)؛ أوقف_النغمة(8)؛ }\n"},
 {"حساس مسافة HC-SR04","فارغ إعداد() { نمط_المنفذ(2، خرج)؛ نمط_المنفذ(3، دخل)؛ تسلسلي.ابدأ(9600)؛ }\nفارغ تكرار() {\n    إشارة_رقمية(2، منخفض)؛ انتظار_ميكروثانية(2)؛\n    إشارة_رقمية(2، مرتفع)؛ انتظار_ميكروثانية(10)؛ إشارة_رقمية(2، منخفض)؛\n    طويل مدة = مدة_نبضة(3، مرتفع، 30000)؛\n    تسلسلي.اطبع_سطر(مدة / 58)؛ انتظار(500)؛\n}\n"},
 {"حرارة ورطوبة DHT22","// ثبّت DHT sensor library للوحة الحقيقية.\n#تضمين <DHT.h>\nحساس_رطوبة حساس(2، DHT22)؛\nفارغ إعداد() { تسلسلي.ابدأ(9600)؛ حساس.ابدأ()؛ }\nفارغ تكرار() {\n    تسلسلي.اطبع_سطر(حساس.اقرأ_حرارة())؛\n    تسلسلي.اطبع_سطر(حساس.اقرأ_رطوبة())؛\n    انتظار(2000)؛\n}\n"},
 {"شاشة LCD 1602","#تضمين <LiquidCrystal.h>\nشاشة_بلورية شاشة(12، 11، 5، 4، 3، 2)؛\nفارغ إعداد() { شاشة.ابدأ(16، 2)؛ شاشة.اطبع(\"Arabduino\")؛ }\nفارغ تكرار() { شاشة.موضع_المؤشر(0، 1)؛ شاشة.اطبع(ميلي_ثانية())؛ انتظار(1000)؛ }\n"},
 {"ريليه وLED","فارغ إعداد() { نمط_المنفذ(7، خرج)؛ }\nفارغ تكرار() { إشارة_رقمية(7، مرتفع)؛ انتظار(1000)؛ إشارة_رقمية(7، منخفض)؛ انتظار(1000)؛ }\n"},
 {"محرك PWM","فارغ إعداد() { نمط_المنفذ(9، خرج)؛ }\nفارغ تكرار() { لكل (صحيح سرعة = 0؛ سرعة <= 255؛ سرعة += 5) { إشارة_تماثلية(9، سرعة)؛ انتظار(40)؛ } }\n"},
 {"حساس ضوء وLED","فارغ إعداد() { نمط_المنفذ(13، خرج)؛ تسلسلي.ابدأ(9600)؛ }\nفارغ تكرار() { صحيح ضوء = قراءة_تماثلية(A0)؛ إشارة_رقمية(13، ضوء < 500)؛ تسلسلي.اطبع_سطر(ضوء)؛ انتظار(100)؛ }\n"},
 {"حركة PIR","فارغ إعداد() { نمط_المنفذ(2، دخل)؛ نمط_المنفذ(13، خرج)؛ }\nفارغ تكرار() { إشارة_رقمية(13، قراءة_رقمية(2))؛ انتظار(30)؛ }\n"},
 {"عصا تحكم","فارغ إعداد() { نمط_المنفذ(2، دخل_سحب)؛ تسلسلي.ابدأ(9600)؛ }\nفارغ تكرار() { تسلسلي.اطبع(قراءة_تماثلية(A0))؛ تسلسلي.اطبع(\" / \")؛ تسلسلي.اطبع_سطر(قراءة_تماثلية(A1))؛ انتظار(100)؛ }\n"},
 {"عرض سبعة مقاطع","فارغ إعداد() { لكل (صحيح منفذ = 2؛ منفذ <= 8؛ منفذ++) { نمط_المنفذ(منفذ، خرج)؛ } }\nفارغ تكرار() { لكل (صحيح منفذ = 2؛ منفذ <= 8؛ منفذ++) { إشارة_رقمية(منفذ، مرتفع)؛ } انتظار(700)؛ لكل (صحيح منفذ = 2؛ منفذ <= 8؛ منفذ++) { إشارة_رقمية(منفذ، منخفض)؛ } انتظار(700)؛ }\n"}
 };
}
public partial class Simulator {
 void PresetAdvanced(string name,bool updateCode){if(!AdvancedExamples.All.ContainsKey(name))return;circuit=new Circuit();pending=null;selected=null;selectedWire=null;outputs.Clear();angles.Clear();modes.Clear();Part part=null;
  Func<string,string,int,int,Part> add=(id,kind,x,y)=>{var d=PartCatalog.Get(kind);var p=new Part(){Id=id,Kind=kind,X=x,Y=y,Value=d.Default,Secondary=kind=="DHT22"?50:512};circuit.Parts.Add(p);return p;};
  Action<Part> power=p=>{Connect(p.Id+".5V","board.5V");Connect(p.Id+".GND","board.GND");};
  Action led=()=>{add("led","LED",680,370);add("r","مقاومة",490,370);Connect("r.A","board.D13");Connect("r.B","led.+");Connect("led.-","board.GND");};
  switch(name){
   case "بريدبورد وLED":add("bread","بريدبورد",440,80);add("led","LED",500,410);add("r","مقاومة",730,410);Connect("board.D13","bread.A1");Connect("bread.E1","r.A");Connect("r.B","led.+");Connect("led.-","bread.F1");Connect("bread.J1","board.GND");break;
   case "ألوان RGB":add("rgb","LED RGB",490,150);Connect("rgb.R","board.D9");Connect("rgb.G","board.D10");Connect("rgb.B","board.D11");Connect("rgb.GND","board.GND");break;
   case "صفارة ونغمة":add("buzzer","صفارة",490,150);Connect("buzzer.+","board.D8");Connect("buzzer.-","board.GND");break;
   case "حساس مسافة HC-SR04":part=add("range","HC-SR04",490,150);power(part);Connect("range.TRIG","board.D2");Connect("range.ECHO","board.D3");break;
   case "حرارة ورطوبة DHT22":part=add("weather","DHT22",490,150);power(part);Connect("weather.DATA","board.D2");break;
   case "شاشة LCD 1602":part=add("lcd","LCD 1602",490,150);power(part);Connect("lcd.RW","board.GND");string[] names={"RS","E","D4","D5","D6","D7"};int[] pins={12,11,5,4,3,2};for(int i=0;i<6;i++)Connect("lcd."+names[i],"board.D"+pins[i]);break;
   case "ريليه وLED":part=add("relay","ريليه",490,130);power(part);Connect("relay.IN","board.D7");add("led","LED",750,330);add("r","مقاومة",490,330);Connect("relay.COM","board.5V");Connect("relay.NO","r.A");Connect("r.B","led.+");Connect("led.-","board.GND");break;
   case "محرك PWM":add("motor","محرك DC",490,150);Connect("motor.+","board.D9");Connect("motor.-","board.GND");break;
   case "حساس ضوء وLED":part=add("light","حساس ضوء",490,130);power(part);Connect("light.OUT","board.A0");led();break;
   case "حركة PIR":part=add("pir","حساس حركة PIR",490,130);power(part);Connect("pir.OUT","board.D2");led();break;
   case "عصا تحكم":part=add("stick","عصا تحكم",490,150);power(part);Connect("stick.X","board.A0");Connect("stick.Y","board.A1");Connect("stick.SW","board.D2");break;
   case "عرض سبعة مقاطع":add("digit","سبعة مقاطع",490,150);for(int i=0;i<7;i++)Connect("digit."+"abcdefg"[i],"board.D"+(i+2));Connect("digit.GND","board.GND");break;
  }
  if(updateCode)example(AdvancedExamples.All[name]);canvas.Invalidate();
 }
}
}
