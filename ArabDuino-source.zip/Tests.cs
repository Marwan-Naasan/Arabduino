using System;
using System.IO;
using Arabduino;
class Tests {
 static int count;
 static void Check(string input,string expected){string actual=Translator.Convert(input);if(actual!=expected)throw new Exception("Mismatch: "+input+" => "+actual+" expected "+expected);count++;}
 static void Main(string[] args){
 Check("فارغ إعداد() { إشارة_رقمية(١٣، مرتفع)؛ }","void setup() { digitalWrite(13, HIGH); }");
 Check("// إشارة_رقمية(١)\nصحيح x=٢؛","// إشارة_رقمية(١)\nint x=2;");
 Check("/* صحيح */ تسلسلي.اطبع_سطر(\"إشارة_رقمية ١؛\");","/* صحيح */ Serial.println(\"إشارة_رقمية ١؛\");");
 Check("char c='؛'; const char* a=\"\\\"صحيح\";","char c='؛'; const char* a=\"\\\"صحيح\";");
 Check("auto t=R\"tag(صحيح ١؛)tag\";","auto t=R\"tag(صحيح ١؛)tag\";");
 Check("صحيحتي = ۱۲۳؛",Translator.Identifier("صحيحتي")+" = 123;");
 Check("صحيح قراءة = ٢؛ تسلسلي.اطبع_سطر(قراءة)؛","int "+Translator.Identifier("قراءة")+" = 2; Serial.println("+Translator.Identifier("قراءة")+");");
 Check("auto t=u8R\"tag(\"صحيح\" ١؛)tag\";","auto t=u8R\"tag(\"صحيح\" ١؛)tag\";");
 Check("#تضمين <صحيح.h>\n#تعريف LED ١٣","#include <صحيح.h>\n#define LED 13");
 Check("void setup(){ digitalWrite(13,HIGH); }","void setup(){ digitalWrite(13,HIGH); }");
 Check("إذا (صواب و ليس خطأ) أرجع؛","if (true and not false) return;");
 Check("// نهاية", "// نهاية");Check("/* بلا نهاية", "/* بلا نهاية");
 foreach(var w in Translator.Words) Check(w.Key,w.Value);
 Console.WriteLine("PASS: "+count+" translator checks");
 if(args.Length>0){Directory.CreateDirectory(args[0]);File.WriteAllText(Path.Combine(args[0],Path.GetFileName(args[0])+".ino"),Translator.Convert(args.Length>1?"فارغ إعداد(){تسلسلي.ابدأ(٩٦٠٠)؛}\nفارغ تكرار(){صحيح قراءة=قراءة_تماثلية(A0)؛ تسلسلي.اطبع_سطر(قراءة)؛ انتظار(٥٠٠)؛}":Translator.Blink),new System.Text.UTF8Encoding(false));}
 }
}
