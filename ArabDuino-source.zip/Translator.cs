using System;
using System.Text;
using System.Collections.Generic;
namespace Arabduino {
public static class Translator {
 static Translator(){ExpandedAliases.Apply(Words);Words["حساس_رطوبة"]="DHT";Words["اقرأ_حرارة"]="readTemperature";Words["اقرأ_رطوبة"]="readHumidity";}
 static readonly System.Text.RegularExpressions.Regex RawPrefix=new System.Text.RegularExpressions.Regex("\\G(?:u8|u|U|L)?R\"",System.Text.RegularExpressions.RegexOptions.Compiled);
 public static readonly Dictionary<string,string> Words = new Dictionary<string,string>(StringComparer.Ordinal) {
 {"إعداد","setup"},{"اعداد","setup"},{"تكرار","loop"},{"حلقة","loop"},
 {"إشارة_رقمية","digitalWrite"},{"اشارة_رقمية","digitalWrite"},{"كتابة_رقمية","digitalWrite"},{"قراءة_رقمية","digitalRead"},
 {"إشارة_تماثلية","analogWrite"},{"اشارة_تماثلية","analogWrite"},{"كتابة_تماثلية","analogWrite"},{"قراءة_تماثلية","analogRead"},
 {"نمط_المنفذ","pinMode"},{"وضع_الدبوس","pinMode"},{"انتظار","delay"},{"انتظار_ميكروثانية","delayMicroseconds"},
 {"مرتفع","HIGH"},{"منخفض","LOW"},{"خرج","OUTPUT"},{"دخل","INPUT"},{"دخل_سحب","INPUT_PULLUP"},{"المصباح_المدمج","LED_BUILTIN"},
 {"فارغ","void"},{"صحيح","int"},{"عدد_صحيح","int"},{"عشري","float"},{"مزدوج","double"},{"حرف","char"},{"نصي","String"},{"منطقي","bool"},{"طويل","long"},{"قصير","short"},{"بايت","byte"},{"غير_موقع","unsigned"},{"ثابت","const"},{"متطاير","volatile"},{"ساكن","static"},
 {"إذا","if"},{"اذا","if"},{"وإلا","else"},{"والا","else"},{"طالما","while"},{"لكل","for"},{"افعل","do"},{"أرجع","return"},{"ارجع","return"},{"توقف","break"},{"تابع","continue"},{"اختر","switch"},{"حالة","case"},{"افتراضي","default"},{"صواب","true"},{"خطأ","false"},{"و","and"},{"أو","or"},{"ليس","not"},{"بنية","struct"},{"صنف","class"},{"عام","public"},{"خاص","private"},{"حجم","sizeof"},
 {"تسلسلي","Serial"},{"ابدأ","begin"},{"اطبع","print"},{"اطبع_سطر","println"},{"متاح","available"},{"اقرأ","read"},{"اكتب","write"},{"ميلي_ثانية","millis"},{"ميكرو_ثانية","micros"},{"عشوائي","random"},{"تحويل_مدى","map"},{"تقييد","constrain"},{"أصغر","min"},{"أكبر","max"},{"مطلق","abs"},{"تضمين","include"},{"تعريف","define"},
 {"سيرفو","Servo"},{"اربط","attach"},{"افصل","detach"},{"شاشة_بلورية","LiquidCrystal"},{"موضع_المؤشر","setCursor"},{"امسح","clear"},{"ذاكرة","EEPROM"},{"حدّث","update"},{"ناقل_سلكي","Wire"},{"ابدأ_إرسال","beginTransmission"},{"أنه_إرسال","endTransmission"},{"واجهة_تسلسلية","SPI"},{"انقل","transfer"}
 };
 static bool Start(char c) { return c=='_' || char.IsLetter(c); }
 static bool Part(char c) { return Start(c) || char.IsDigit(c) || char.GetUnicodeCategory(c)==System.Globalization.UnicodeCategory.NonSpacingMark; }
 public static string Identifier(string word) {
  if(!System.Linq.Enumerable.Any(word,c=>c>127))return word;
  var encoded=new StringBuilder("arabduino_id_");foreach(char c in word)encoded.Append(((int)c).ToString("x4"));return encoded.ToString();
 }
 public static string Convert(string source) {
  var b=new StringBuilder(); int i=0;
  while(i<source.Length) {
   char c=source[i];
   if(i+1<source.Length && c=='/' && (source[i+1]=='/' || source[i+1]=='*')) {
    int start=i; bool line=source[i+1]=='/'; i+=2;
    if(line) {while(i<source.Length && source[i]!='\n') i++;}
    else {while(i+1<source.Length && !(source[i]=='*' && source[i+1]=='/')) i++; i=Math.Min(source.Length,i+2);}
    b.Append(source,start,i-start); continue;
   }
   // Preserve C++ raw literals, including custom delimiters.
   var raw=RawPrefix.Match(source,i);
   if(raw.Success) {
    int delimiter=i+raw.Length;int paren=source.IndexOf('(',delimiter);
    if(paren>=0 && paren-delimiter<=16) {string ending=")"+source.Substring(delimiter,paren-delimiter)+"\""; int end=source.IndexOf(ending,paren+1,StringComparison.Ordinal); if(end>=0) {end+=ending.Length;b.Append(source,i,end-i);i=end;continue;}}
   }
   if(c=='"' || c=='\'') {int start=i++; while(i<source.Length) {if(source[i]=='\\') {i=Math.Min(source.Length,i+2);continue;} if(source[i++]==c)break;} b.Append(source,start,i-start);continue;}
   // Angle-bracket header paths must never be translated.
   if(c=='<' && System.Text.RegularExpressions.Regex.IsMatch(b.ToString(), @"#\s*(include|تضمين)\s*$")) {int end=source.IndexOf('>',i); if(end>=0){b.Append(source,i,end-i+1);i=end+1;continue;}}
   if(Start(c)) {int start=i++;while(i<source.Length && Part(source[i]))i++;string word=source.Substring(start,i-start);string value;b.Append(Words.TryGetValue(word,out value)?value:Identifier(word));continue;}
   if(c>='٠' && c<='٩') b.Append((char)('0'+c-'٠'));
   else if(c>='۰' && c<='۹') b.Append((char)('0'+c-'۰'));
   else if(c=='؛') b.Append(';'); else if(c=='،')b.Append(','); else b.Append(c);
   i++;
  }
  return b.ToString();
 }
 public const string Blink = "// Arabduino — وميض المصباح المدمج\nفارغ إعداد() {\n    نمط_المنفذ(المصباح_المدمج، خرج)؛\n}\n\nفارغ تكرار() {\n    إشارة_رقمية(المصباح_المدمج، مرتفع)؛\n    انتظار(1000)؛\n    إشارة_رقمية(المصباح_المدمج، منخفض)؛\n    انتظار(1000)؛\n}\n";
}
}
