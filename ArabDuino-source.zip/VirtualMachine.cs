using System;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
namespace Arabduino {
public interface IVirtualBoard {double Read(int pin,bool analog);void Write(int pin,double value,bool analog);void Mode(int pin,int mode);void Servo(int pin,double angle);void Print(string text);}
public interface IVirtualFeatures {void Tone(int pin,double frequency,double duration);double Pulse(int pin,double level,double timeout);double Dht(int pin,bool temperature);void Lcd(int[] pins,string command,double[] args,string text);}
public class VirtualMachine {
 public sealed class Node {public string Kind;public List<string> A=new List<string>(),B=new List<string>(),C=new List<string>();public List<Node> Body=new List<Node>(),Other=new List<Node>();}
 readonly IVirtualBoard hardware;readonly Dictionary<string,double> vars=new Dictionary<string,double>();readonly Dictionary<string,int> servos=new Dictionary<string,int>();
 readonly Dictionary<string,int[]> displays=new Dictionary<string,int[]>();readonly Dictionary<string,int> sensors=new Dictionary<string,int>();Random random=new Random(1);
 List<string> tokens;int at,steps;double clock,pendingDelay;CancellationToken cancel;public double Speed=1;public bool Paused;
 public VirtualMachine(IVirtualBoard board){hardware=board;}
 static HashSet<string> types=new HashSet<string>(new[]{"int","float","double","long","short","byte","char","bool","unsigned","const","static","volatile","String"});
 string Peek {get{return at<tokens.Count?tokens[at]:"<end>";}}
 string Next(){string s=Peek;at++;return s;}
 void Need(string value){if(Next()!=value)throw new Exception("المحاكي يتوقع: "+value+". استخدم أحد أمثلة المحاكاة المدعومة.");}
 List<string> Until(string end){var list=new List<string>();int level=0;while(Peek!="<end>"){if(Peek==end&&level==0){Next();return list;}string t=Next();if(t=="("||t=="[")level++;if(t==")"||t=="]")level--;list.Add(t);}throw new Exception("قوس أو فاصلة منقوطة مفقودة في المحاكاة.");}
 List<string> Condition(){Need("(");return Until(")");}
 Node Statement(){
  string kind=Next();var node=new Node(){Kind=kind};
  if(kind=="{"){while(Peek!="}"&&Peek!="<end>")node.Body.Add(Statement());Need("}");return node;}
  if(kind=="if"){node.A=Condition();node.Body.Add(Statement());if(Peek=="else"){Next();node.Other.Add(Statement());}return node;}
  if(kind=="while"){node.A=Condition();node.Body.Add(Statement());return node;}
  if(kind=="for"){Need("(");node.A=Until(";");node.B=Until(";");node.C=Until(")");node.Body.Add(Statement());return node;}
  if(kind=="break"||kind=="continue"||kind=="return"){node.A=Until(";");return node;}
  if(kind=="<end>")throw new Exception("نهاية كود غير متوقعة.");
  node.Kind="expr";at--;node.A=Until(";");return node;
 }
 public async Task Run(string source,CancellationToken token){
  cancel=token;vars.Clear();servos.Clear();displays.Clear();sensors.Clear();clock=0;steps=0;pendingDelay=0;
  vars["HIGH"]=1;vars["LOW"]=0;vars["OUTPUT"]=1;vars["INPUT"]=0;vars["INPUT_PULLUP"]=2;vars["LED_BUILTIN"]=13;vars["true"]=1;vars["false"]=0;for(int i=0;i<6;i++)vars["A"+i]=14+i;
  vars["PI"]=Math.PI;vars["TWO_PI"]=Math.PI*2;vars["HALF_PI"]=Math.PI/2;vars["DEG_TO_RAD"]=Math.PI/180;vars["RAD_TO_DEG"]=180/Math.PI;vars["DHT22"]=22;vars["HEX"]=16;vars["DEC"]=10;
  string text=Translator.Convert(source);text=Regex.Replace(text,@"^\s*#[^\r\n]*","",RegexOptions.Multiline);
  var matches=Regex.Matches(text,@"//[^\r\n]*|/\*[\s\S]*?\*/|""(?:\\[\s\S]|[^""\\])*""|'(?:\\.|[^'\\])*'|\d+(?:\.\d+)?|[A-Za-z_]\w*|==|!=|<=|>=|\+\+|--|\+=|-=|&&|\|\||\S");
  tokens=matches.Cast<Match>().Select(m=>m.Value).Where(t=>!t.StartsWith("//")&&!t.StartsWith("/*")).ToList();at=0;var functions=new Dictionary<string,Node>();var globals=new List<Node>();
  while(Peek!="<end>"){
   if(at+2<tokens.Count&&tokens[at+2]=="("&&tokens[at]=="void") {Next();string name=Next();Need("(");Need(")");functions[name]=Statement();}
   else globals.Add(Statement());
  }
  if(!functions.ContainsKey("setup")||!functions.ContainsKey("loop"))throw new Exception("المحاكي يحتاج فارغ إعداد() وفارغ تكرار().");
  foreach(var node in globals)await Execute(node);try{await Execute(functions["setup"]);}catch(ReturnSignal){}
  while(true){cancel.ThrowIfCancellationRequested();try{await Execute(functions["loop"]);}catch(ReturnSignal){}await Task.Delay(1,cancel);clock+=1;}
 }
 class BreakSignal:Exception{} class ContinueSignal:Exception{} class ReturnSignal:Exception{}
 async Task Tick(){cancel.ThrowIfCancellationRequested();while(Paused)await Task.Delay(30,cancel);if(++steps%100==0)await Task.Delay(1,cancel);if(steps>10000000)throw new Exception("تجاوزت المحاكاة حد العمليات. أعد التشغيل أو بسّط الكود.");}
 async Task Execute(Node n){await Tick();switch(n.Kind){
 case "{":foreach(var child in n.Body)await Execute(child);break;
 case "if":foreach(var child in (Eval(n.A)!=0?n.Body:n.Other))await Execute(child);break;
 case "while":while(Eval(n.A)!=0){await Tick();try{foreach(var child in n.Body)await Execute(child);}catch(BreakSignal){break;}catch(ContinueSignal){}}break;
 case "for":Eval(n.A);while(n.B.Count==0||Eval(n.B)!=0){await Tick();try{foreach(var child in n.Body)await Execute(child);}catch(BreakSignal){break;}catch(ContinueSignal){}Eval(n.C);}break;
 case "break":throw new BreakSignal();case "continue":throw new ContinueSignal();case "return":throw new ReturnSignal();
 default:Eval(n.A);if(pendingDelay>0){double d=pendingDelay;pendingDelay=0;clock+=d;await Task.Delay((int)Math.Min(60000,Math.Max(1,d/Math.Max(0.1,Speed))),cancel);}break;
 }}
 public double Eval(List<string> input){
  if(input.Count==0)return 0;var list=new List<string>(input);int i=0;bool declaration=false;
  while(i<list.Count&&types.Contains(list[i])){i++;declaration=true;}
  if(list.Count>3&&(list[0]=="LiquidCrystal"||list[0]=="DHT")){string kind=list[0],name=list[1];if(list[2]!="("||list[list.Count-1]!=")")throw new Exception("تعريف كائن مكتبة غير مدعوم.");var args=new List<int>();i=3;while(i<list.Count-1){args.Add((int)Expression(list,ref i,0));if(i<list.Count-1&&list[i]==",")i++;else break;}if(kind=="LiquidCrystal"){if(args.Count!=6)throw new Exception("المحاكي يدعم LiquidCrystal في نمط4 بت ذي6 منافذ تحكم.");displays[name]=args.ToArray();}else{if(args.Count!=2||args[1]!=22)throw new Exception("المحاكي يدعم DHT22 فقط بهذه الواجهة.");sensors[name]=args[0];}return 0;}
  if(i<list.Count&&list[i]=="Servo"){if(i+1>=list.Count)throw new Exception("اسم السيرفو مفقود.");servos[list[i+1]]=9;return 0;}
  if(i>=list.Count)return 0;
  if(declaration){string name=list[i++];if(i==list.Count){vars[name]=0;return 0;}if(list[i++]!="=")throw new Exception("تصريح متغير غير مدعوم بالمحاكي.");double v=Expression(list,ref i,0);vars[name]=v;if(i!=list.Count)throw new Exception("تصريح غير مدعوم. عرّف كل متغير بسطر مستقل.");return v;}
  if(i+1<list.Count&&(list[i+1]=="="||list[i+1]=="+="||list[i+1]=="-=")){string name=list[i],op=list[i+1];i+=2;double value=Expression(list,ref i,0);if(op!="=")value=Get(name)+(op=="+="?value:-value);vars[name]=value;if(i!=list.Count)throw new Exception("تعبير غير مدعوم.");return value;}
  double result=Expression(list,ref i,0);if(i!=list.Count)throw new Exception("صيغة C++ غير مدعومة في المحاكي قرب "+list[i]);return result;
 }
 double Get(string name){double value;if(vars.TryGetValue(name,out value))return value;throw new Exception("اسم غير معرّف في المحاكاة: "+name);}
 int Precedence(string op){switch(op){case "||":case "or":return 1;case "&&":case "and":return 2;case "==":case "!=":return 3;case "<":case ">":case "<=":case ">=":return 4;case "+":case "-":return 5;case "*":case "/":case "%":return 6;default:return -1;}}
 double Expression(List<string> t,ref int i,int minimum){
  if(i>=t.Count)throw new Exception("تعبير ناقص في المحاكاة.");string current=t[i++];double left;
  if(current=="!"||current=="not"||current=="-"||current=="+"){left=Expression(t,ref i,7);if(current=="!"||current=="not")left=left==0?1:0;else if(current=="-")left=-left;}
  else if(current=="("){left=Expression(t,ref i,0);if(i>=t.Count||t[i++]!=")")throw new Exception("قوس ناقص.");}
  else if(current.StartsWith("'")&&current.EndsWith("'")){string value=Regex.Unescape(current.Substring(1,current.Length-2));if(value.Length!=1)throw new Exception("المحاكي يدعم محرفاً بايتياً واحداً فقط.");left=value[0];}
  else if(double.TryParse(current,NumberStyles.Float,CultureInfo.InvariantCulture,out left)){}
  else {
   string name=current;
   if(i<t.Count&&t[i]=="."){i++;if(i>=t.Count)throw new Exception("اسم دالة ناقص.");name+="."+t[i++];}
   if(i<t.Count&&t[i]=="("){
    i++;var args=new List<double>();string literal=null;
    while(i<t.Count&&t[i]!=")"){if(t[i].StartsWith("\"")){literal=t[i++];args.Add(0);}else args.Add(Expression(t,ref i,0));if(i<t.Count&&t[i]==",")i++;else break;}
    if(i>=t.Count||t[i++]!=")")throw new Exception("وسائط دالة غير صالحة.");left=Call(name,args,literal);
   }else{left=Get(name);if(i<t.Count&&(t[i]=="++"||t[i]=="--")){vars[name]=left+(t[i++]=="++"?1:-1);}}
  }
  while(i<t.Count){string op=t[i];int precedence=Precedence(op);if(precedence<minimum)break;i++;double right=Expression(t,ref i,precedence+1);switch(op){case "+":left+=right;break;case "-":left-=right;break;case "*":left*=right;break;case "/":if(right==0)throw new Exception("قسمة على صفر.");left/=right;break;case "%":left%=right;break;case "==":left=left==right?1:0;break;case "!=":left=left!=right?1:0;break;case "<":left=left<right?1:0;break;case ">":left=left>right?1:0;break;case "<=":left=left<=right?1:0;break;case ">=":left=left>=right?1:0;break;case "&&":case "and":left=left!=0&&right!=0?1:0;break;case "||":case "or":left=left!=0||right!=0?1:0;break;}}
  return left;
 }
 void Count(List<double> args,int count,string name){if(args.Count!=count)throw new Exception("عدد وسائط غير صحيح: "+name);}
 double Call(string name,List<double> a,string literal){
  var features=hardware as IVirtualFeatures;
  switch(name){
   case "tone":if(a.Count<2||a.Count>3||features==null)throw new Exception("tone يحتاج2 أو3 وسائط ودارة تدعم الصوت.");features.Tone((int)a[0],a[1],a.Count>2?a[2]:0);return 0;
   case "noTone":Count(a,1,name);if(features==null)throw new Exception("الصوت غير متاح.");features.Tone((int)a[0],0,0);return 0;
   case "pulseIn":case "pulseInLong":if(a.Count<2||a.Count>3||features==null)throw new Exception("قياس النبضة يحتاج2 أو3 وسائط.");return features.Pulse((int)a[0],a[1],a.Count>2?a[2]:1000000);
   case "pinMode":Count(a,2,name);hardware.Mode((int)a[0],(int)a[1]);return 0;
   case "digitalWrite":case "analogWrite":Count(a,2,name);hardware.Write((int)a[0],a[1],name=="analogWrite");return 0;
   case "digitalRead":case "analogRead":Count(a,1,name);return hardware.Read((int)a[0],name=="analogRead");
   case "delay":case "delayMicroseconds":Count(a,1,name);if(a[0]<0)throw new Exception("مدة انتظار سالبة.");pendingDelay=a[0]/(name=="delay"?1:1000);return 0;
   case "millis":return clock;case "micros":return clock*1000;
   case "Serial.begin":Count(a,1,name);return 0;
   case "Serial.print":case "Serial.println":Count(a,1,name);string output=literal==null?a[0].ToString("0.###",CultureInfo.InvariantCulture):Regex.Unescape(literal.Substring(1,literal.Length-2));hardware.Print(output+(name=="Serial.println"?"\n":""));return 0;
   case "map":Count(a,5,name);if(a[2]==a[1])throw new Exception("مدى غير صالح.");return Math.Truncate((a[0]-a[1])*(a[4]-a[3])/(a[2]-a[1])+a[3]);
   case "constrain":Count(a,3,name);return Math.Max(a[1],Math.Min(a[2],a[0]));
   case "abs":Count(a,1,name);return Math.Abs(a[0]);case "min":Count(a,2,name);return Math.Min(a[0],a[1]);case "max":Count(a,2,name);return Math.Max(a[0],a[1]);
   case "pow":Count(a,2,name);return Math.Pow(a[0],a[1]);case "sq":Count(a,1,name);return a[0]*a[0];case "sqrt":Count(a,1,name);return Math.Sqrt(a[0]);case "sin":Count(a,1,name);return Math.Sin(a[0]);case "cos":Count(a,1,name);return Math.Cos(a[0]);case "tan":Count(a,1,name);return Math.Tan(a[0]);
   case "randomSeed":Count(a,1,name);random=new Random((int)a[0]);return 0;case "random":if(a.Count==1)return Math.Floor(random.NextDouble()*a[0]);if(a.Count==2)return Math.Floor(a[0]+random.NextDouble()*(a[1]-a[0]));throw new Exception("عدد وسائط random غير صحيح.");
   case "bit":Count(a,1,name);return (double)(1UL<<(int)a[0]);case "bitRead":Count(a,2,name);return ((ulong)a[0]>>(int)a[1])&1;case "highByte":Count(a,1,name);return ((ulong)a[0]>>8)&255;case "lowByte":Count(a,1,name);return (ulong)a[0]&255;
   case "isnan":Count(a,1,name);return double.IsNaN(a[0])?1:0;
  }
  int member=name.IndexOf('.');if(member>0){string obj=name.Substring(0,member),method=name.Substring(member+1);if(features!=null&&displays.ContainsKey(obj)){if(method=="begin"){Count(a,2,name);if(a[0]!=16||a[1]!=2)throw new Exception("المحاكي يدعم شاشة16x2 فقط.");}else if(method=="setCursor")Count(a,2,name);else if(method=="print")Count(a,1,name);else if(new[]{"clear","home","display","noDisplay"}.Contains(method))Count(a,0,name);else throw new Exception("طريقة LCD غير مدعومة: "+method);string text=literal==null?(a.Count>0?a[0].ToString("0.###",CultureInfo.InvariantCulture):""):Regex.Unescape(literal.Substring(1,literal.Length-2));features.Lcd(displays[obj],method,a.ToArray(),text);return 0;}if(features!=null&&sensors.ContainsKey(obj)){Count(a,0,name);if(method=="begin")return 0;if(method=="readTemperature"||method=="readHumidity")return features.Dht(sensors[obj],method=="readTemperature");throw new Exception("طريقة DHT غير مدعومة: "+method);}}
  int dot=name.IndexOf('.');if(dot>0){string obj=name.Substring(0,dot),method=name.Substring(dot+1);if(servos.ContainsKey(obj)){Count(a,1,name);if(method=="attach"){servos[obj]=(int)a[0];return 0;}if(method=="write"){hardware.Servo(servos[obj],a[0]);return 0;}}}
  throw new Exception("الدالة غير مدعومة بالمحاكي المحلي: "+name+". يمكن استخدامها عند التحقق والرفع للوحة الحقيقية.");
 }
}
}
