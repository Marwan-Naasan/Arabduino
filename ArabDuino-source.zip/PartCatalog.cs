using System;
using System.Drawing;
using System.Linq;
using System.Collections.Generic;
namespace Arabduino {
public class PartDefinition {
 public string Name,Category,Description,ValueLabel,SecondaryLabel,Support;public string[] Pins;public int Width=150,Height=132,Min=0,Max=1023,Default=512;public bool Simulated=true,AnalogInput,DigitalInput;public Color Color=Color.FromArgb(52,112,147);
}
public static class PartCatalog {
 public static readonly List<PartDefinition> All=Create();
 static List<PartDefinition> Create(){var a=new List<PartDefinition>();
  Action<string,string,string,string[]> add=(name,category,description,pins)=>a.Add(new PartDefinition(){Name=name,Category=category,Description=description,Pins=pins,Support="نموذج منطقي تعليمي"});
  add("بريدبورد","لوحات وتوصيل","30 عموداً. A..E في العمود نفسه موصولة، وF..J مجموعة مستقلة. كل سكة تغذية مستقلة عن الأخرى.",new string[0]);a.Last().Width=620;a.Last().Height=280;
  add("بريدبورد صغيرة","لوحات وتوصيل","10 أعمدة مع مجموعتين من خمس ثقوب في كل عمود. الفاصل الأوسط يعزل المجموعتين.",new string[0]);a.Last().Width=260;a.Last().Height=250;
  add("LED","إضاءة","مصباح أحادي. وصل + إلى خرج عبر مقاومة و- إلى الأرضي.",new[]{"+","-"});
  add("LED RGB","إضاءة","ثلاثة ألوان مع مهبط مشترك GND؛ لكل قناة مقاومة مستقلة على اللوحة الحقيقية.",new[]{"R","G","B","GND"});
  add("شريط LED","إضاءة","10 مصابيح مستقلة ذات أرضي مشترك؛ هذا ليس شريط NeoPixel معنونا.",Enumerable.Range(1,10).Select(i=>"L"+i).Concat(new[]{"GND"}).ToArray());a.Last().Width=300;
  add("سبعة مقاطع","شاشات","عرض مقطع واحد بمهبط مشترك. الأطراف a..g وdp تتحكم بالمقاطع رقمياً.",new[]{"a","b","c","d","e","f","g","dp","GND"});a.Last().Width=210;
  add("مقاومة","لوحات وتوصيل","عنصر توصيل تسلسلي في المحاكي المنطقي؛ القيمة تُحفظ ولا تُحلّ معادلات الجهد والتيار.",new[]{"A","B"});a.Last().Max=1000000;a.Last().Default=220;a.Last().ValueLabel="المقاومة Ω";
  add("زر","مداخل","زر لحظي يوصل A بـB أثناء الضغط فقط.",new[]{"A","B"});
  add("مفتاح منزلق","مداخل","مفتاح SPDT يوصل COM إلى A أو B بحسب وضعه. انقره لتبديل الوضع.",new[]{"A","COM","B"});a.Last().Max=1;a.Last().Default=0;a.Last().ValueLabel="وضع المفتاح";
  add("مقاومة متغيرة","مداخل","مدخل تناظري قابل للضبط. يحتاج5V وGND، ويوصل OUT إلى منفذ A.",new[]{"5V","OUT","GND"});a.Last().AnalogInput=true;a.Last().ValueLabel="قراءة ADC";
  add("منزلق تماثلي","مداخل","مدخل تماثلي خطي يعرض قيمة يحددها المنزلق؛ ليس نموذج مقاومة كهربائياً.",new[]{"5V","OUT","GND"});a.Last().AnalogInput=true;a.Last().ValueLabel="قراءة ADC";
  add("حساس ضوء","حساسات","وحدة ضوء تماثلية افتراضية؛ اضبط قراءة ADC مباشرة من الخصائص.",new[]{"5V","OUT","GND"});a.Last().AnalogInput=true;a.Last().ValueLabel="قراءة الضوء ADC";
  add("حساس NTC","حساسات","وحدة حرارية تماثلية؛ تضبط قراءة ADC الخام، وليست الحرارة المحسوبة أو خصائص مقاومة حقيقية.",new[]{"5V","OUT","GND"});a.Last().AnalogInput=true;a.Last().ValueLabel="قراءة NTC الخام";
  add("حساس غاز","حساسات","وحدة غاز تماثلية تعليمية؛ القيمة هي قراءة ADC، وليست تركيزاً فيزيائياً معايراً.",new[]{"5V","OUT","GND"});a.Last().AnalogInput=true;a.Last().ValueLabel="قراءة الغاز ADC";
  add("حساس حركة PIR","حساسات","خرج رقمي يدل على الحركة. يحتاج تغذية وأرضياً. انقره لتبديل الحركة.",new[]{"5V","OUT","GND"});a.Last().DigitalInput=true;a.Last().Default=0;a.Last().Max=1;a.Last().ValueLabel="وجود حركة";
  add("عصا تحكم","مداخل","محوران تماثليان X وY وزر SW يصل إلى GND عند الضغط.",new[]{"5V","X","Y","SW","GND"});a.Last().Width=190;a.Last().AnalogInput=true;a.Last().ValueLabel="محور X";a.Last().SecondaryLabel="محور Y";
  add("صفارة","مخارج ومحركات","تستجيب لنغمة tone أو لخرج رقمي. التردد ظاهر، والصوت اختياري من الشريط العلوي.",new[]{"+","-"});
  add("سيرفو","مخارج ومحركات","يعرض زاوية Servo.write عند وصول التغذية والأرضي والإشارة إلى منفذ attach.",new[]{"5V","SIG","GND"});
  add("ريليه","مخارج ومحركات","وحدة ريليه نشطة بمرتفع؛ COM متصل بـNC عند الفصل وبـNO عند التشغيل. النموذج لا يحاكي ملفاً أو جهداً عالياً.",new[]{"5V","IN","GND","COM","NO","NC"});a.Last().Width=220;
  add("محرك DC","مخارج ومحركات","نموذج سرعة يتبع خرجاً رقمياً أوPWM. في الواقع يحتاج المحرك دارة قيادة وتغذية مناسبة؛ لا توصله مباشرة بالمنفذ.",new[]{"+","-"});
  add("HC-SR04","حساسات","حساس مسافة. أرسل نبضة TRIG واقرأ ECHO بواسطة pulseIn؛ المسافة بالسم تضبط من الخصائص. النموذج لا يحاكي انتشار الصوت.",new[]{"5V","TRIG","ECHO","GND"});a.Last().Width=190;a.Last().Min=2;a.Last().Max=400;a.Last().Default=100;a.Last().ValueLabel="المسافة cm";
  add("DHT22","حساسات","حرارة ورطوبة قابلة للتغيير. يدعم المحاكي الواجهة المحددة لمكتبة Adafruit DHT؛ لا يحاكي البروتوكول البايتي بتوقيته.",new[]{"5V","DATA","GND"});a.Last().Min=-40;a.Last().Max=80;a.Last().Default=24;a.Last().ValueLabel="الحرارة °C";a.Last().SecondaryLabel="الرطوبة %";
  add("LCD 1602","شاشات","شاشة16x2 في نمط4 بت مع LiquidCrystal. وصل RS وE وD4..D7 والتغذية والأرضي، واربط RW بالأرضي.",new[]{"5V","GND","RS","E","D4","D5","D6","D7","RW"});a.Last().Width=300;a.Last().Height=150;
  add("مسبار منطقي","قياس","يعرض مستوى منفذ رقمي أو نسبةPWM عند توصيل IN والأرضي.",new[]{"IN","GND"});
  add("مكثف","رسم فقط","رمز تخطيطي قابل للتوصيل والحفظ. لا يحاكي هذا الإصدار الشحن والتفريغ أو تأثيره في الشبكة.",new[]{"+","-"});a.Last().Simulated=false;
  add("ترانزستور NPN","رسم فقط","عنصر توضيحي؛ أطراف C وB وE غير موصولة داخلياً ولا ينفذ المحاكي انحياز الترانزستور.",new[]{"C","B","E"});a.Last().Simulated=false;
  add("OLED I2C","رسم فقط","شاشة توضيحية بتوصيلات I2C. مكتبات عرضOLED غير منفذة بالمحاكي الحالي؛ يظهر عليها رسم فقط.",new[]{"5V","GND","SDA","SCL"});a.Last().Simulated=false;
  return a;
 }
 public static PartDefinition Get(string kind){return All.FirstOrDefault(d=>d.Name==kind);}
 public static string[] Names(Part p){if(p.Kind=="بريدبورد"||p.Kind=="بريدبورد صغيرة"){int columns=p.Kind=="بريدبورد"?30:10;var pins=new List<string>();foreach(char row in "ABCDEFGHIJ")for(int col=1;col<=columns;col++)pins.Add(row+col.ToString());if(columns==30)foreach(char rail in "PNQM")for(int col=1;col<=columns;col++)pins.Add(rail+col.ToString());return pins.ToArray();}var d=Get(p.Kind);return d==null?new string[0]:d.Pins;}
 public static Size Size(Part p){var d=Get(p.Kind);int w=d==null?150:d.Width,h=d==null?132:d.Height;return p.Rotation%2==0?new Size(w,h):new Size(h,w);}
 public static Point Rotate(Part p,Point local){var d=Get(p.Kind);int w=d.Width,h=d.Height;switch((p.Rotation%4+4)%4){case 1:return new Point(p.X+h-local.Y,p.Y+local.X);case 2:return new Point(p.X+w-local.X,p.Y+h-local.Y);case 3:return new Point(p.X+local.Y,p.Y+w-local.X);default:return new Point(p.X+local.X,p.Y+local.Y);}}
 public static Dictionary<string,Point> Pins(Part p){var result=new Dictionary<string,Point>();var d=Get(p.Kind);if(d==null)return result;
  if(p.Kind.StartsWith("بريدبورد")){int columns=p.Kind=="بريدبورد"?30:10;foreach(char row in "ABCDEFGHIJ")for(int col=1;col<=columns;col++){int r=row-'A';result[p.Id+"."+row+col]=Rotate(p,new Point(40+(col-1)*18,55+r*16+(r>=5?22:0)));}if(columns==30)foreach(char rail in "PNQM")for(int col=1;col<=columns;col++)result[p.Id+"."+rail+col]=Rotate(p,new Point(40+(col-1)*18,rail=='P'?22:rail=='N'?36:rail=='Q'?250:264));
  }else{for(int i=0;i<d.Pins.Length;i++){int perRow=d.Pins.Length>6?(d.Pins.Length+1)/2:d.Pins.Length;int row=i/perRow;result[p.Id+"."+d.Pins[i]]=Rotate(p,new Point(18+(i%perRow)*(d.Width-36)/Math.Max(1,perRow-1),d.Height-12-row*23));}}
  return result;
 }
}
public class CircuitGraph {
 Dictionary<string,List<string>> edges=new Dictionary<string,List<string>>();
 void Edge(string a,string b){if(!edges.ContainsKey(a))edges[a]=new List<string>();if(!edges.ContainsKey(b))edges[b]=new List<string>();edges[a].Add(b);edges[b].Add(a);}
 void Group(IEnumerable<string> names){var a=names.ToArray();for(int i=1;i<a.Length;i++)Edge(a[0],a[i]);}
 public CircuitGraph(Circuit c){foreach(var w in c.Wires)if(w!=null&&w.A!=null&&w.B!=null)Edge(w.A,w.B);foreach(var p in c.Parts){string id=p.Id+".";
  if(p.Kind.StartsWith("بريدبورد")){int n=p.Kind=="بريدبورد"?30:10;for(int col=1;col<=n;col++){Group("ABCDE".Select(r=>id+r+col));Group("FGHIJ".Select(r=>id+r+col));}if(n==30)foreach(char rail in "PNQM")Group(Enumerable.Range(1,30).Select(i=>id+rail+i));}
  else if(p.Kind=="مقاومة"||(p.Kind=="زر"&&p.Pressed))Edge(id+"A",id+"B");else if(p.Kind=="مفتاح منزلق")Edge(id+"COM",id+(p.Value==0?"A":"B"));else if(p.Kind=="عصا تحكم"&&p.Pressed)Edge(id+"SW",id+"GND");else if(p.Kind=="ريليه")Edge(id+"COM",id+(p.Active?"NO":"NC"));
 }}
 public HashSet<string> Connected(string start){var seen=new HashSet<string>(){start};var queue=new Queue<string>();queue.Enqueue(start);while(queue.Count>0){List<string> links;if(!edges.TryGetValue(queue.Dequeue(),out links))continue;foreach(string next in links)if(seen.Add(next))queue.Enqueue(next);}return seen;}
}
}
