// ثبّت DHT sensor library للوحة الحقيقية.
#include <DHT.h>
DHT arabduino_id_062d063306270633(2, DHT22);
void setup() {
    Serial.begin(9600);
arabduino_id_062d063306270633.begin();
}
void loop() {
    Serial.println(arabduino_id_062d063306270633.readTemperature());
    Serial.println(arabduino_id_062d063306270633.readHumidity());
    delay(2000);
}
