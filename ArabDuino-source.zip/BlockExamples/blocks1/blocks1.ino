// صِل الزر بين D2 و GND. وLED بين D13 ومقاومة ثم GND.
void setup() {
    pinMode(2, INPUT_PULLUP);
    pinMode(13, OUTPUT);
}
void loop() {
    if (digitalRead(2) == LOW) {
        digitalWrite(13, HIGH);
    }
    else {
        digitalWrite(13, LOW);
    }
    delay(20);
}
