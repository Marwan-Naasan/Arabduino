#include <LiquidCrystal.h>
LiquidCrystal arabduino_id_0634062706340629(12, 11, 5, 4, 3, 2);
void setup() {
arabduino_id_0634062706340629.begin(16, 2);
arabduino_id_0634062706340629.print("Arabduino");
}
void loop() {
arabduino_id_0634062706340629.setCursor(0, 1);
arabduino_id_0634062706340629.print(millis());
    delay(1000);
}
