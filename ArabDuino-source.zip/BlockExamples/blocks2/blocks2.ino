// خرج المقاومة المتغيرة إلى A0. وLED مع مقاومة على D9.
void setup() {
    pinMode(9, OUTPUT);
    Serial.begin(9600);
}
void loop() {
    int arabduino_id_06420631062706210629 = analogRead(A0);
    int arabduino_id_0633063706480639 = map(arabduino_id_06420631062706210629, 0, 1023, 0, 255);
    analogWrite(9, arabduino_id_0633063706480639);
    Serial.println(arabduino_id_06420631062706210629);
    delay(50);
}
