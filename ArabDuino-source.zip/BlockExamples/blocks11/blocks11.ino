void setup() {
    pinMode(2, OUTPUT);
    pinMode(3, INPUT);
    Serial.begin(9600);
}
void loop() {
    digitalWrite(2, LOW);
delayMicroseconds(2);
    digitalWrite(2, HIGH);
delayMicroseconds(10);
    digitalWrite(2, LOW);
long arabduino_id_0645062f0629 = pulseIn(3, HIGH, 30000);
    Serial.println(arabduino_id_0645062f0629 / 58);
    delay(500);
}
