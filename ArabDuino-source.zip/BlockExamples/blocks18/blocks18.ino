void setup() {
    pinMode(2, INPUT_PULLUP);
    Serial.begin(9600);
}
void loop() {
Serial.print(analogRead(A0));
Serial.print(" / ");
    Serial.println(analogRead(A1));
    delay(100);
}
