void setup() {
    for (int arabduino_id_0645064606410630 = 2; arabduino_id_0645064606410630 <= 8; arabduino_id_0645064606410630++) {
        pinMode(arabduino_id_0645064606410630, OUTPUT);
    }
}
void loop() {
    for (int arabduino_id_0645064606410630 = 2; arabduino_id_0645064606410630 <= 8; arabduino_id_0645064606410630++) {
        digitalWrite(arabduino_id_0645064606410630, HIGH);
    }
    delay(700);
    for (int arabduino_id_0645064606410630 = 2; arabduino_id_0645064606410630 <= 8; arabduino_id_0645064606410630++) {
        digitalWrite(arabduino_id_0645064606410630, LOW);
    }
    delay(700);
}
