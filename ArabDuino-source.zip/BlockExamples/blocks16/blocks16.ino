void setup() {
    pinMode(13, OUTPUT);
    Serial.begin(9600);
}
void loop() {
    int arabduino_id_063606480621 = analogRead(A0);
    digitalWrite(13, arabduino_id_063606480621 < 500);
    Serial.println(arabduino_id_063606480621);
    delay(100);
}
