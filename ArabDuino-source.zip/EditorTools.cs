using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.InteropServices;
namespace Arabduino {
public static class CodeFormat {
 static readonly Regex rawPrefix=new Regex("\\G(?:u8|u|U|L)?R\"",RegexOptions.Compiled);
 public static string LatinDigits(string text){var b=new StringBuilder(text.Length);foreach(char c in text){if(c>='\u0660'&&c<='\u0669')b.Append((char)('0'+c-'\u0660'));else if(c>='\u06f0'&&c<='\u06f9')b.Append((char)('0'+c-'\u06f0'));else b.Append(c);}return b.ToString();}
 public static string NormalizeNumbers(string text){var b=new StringBuilder();for(int i=0;i<text.Length;){int end=SkipLiteral(text,i);if(end>i){b.Append(text,i,end-i);i=end;}else{b.Append(LatinDigits(text[i].ToString()));i++;}}return b.ToString();}
 // Walk lexical regions so braces inside comments, strings and raw strings do not indent code.
 public static int SkipLiteral(string text,int i){
  if(i+1<text.Length&&text[i]=='/'&&text[i+1]=='/'){int end=text.IndexOf('\n',i+2);return end<0?text.Length:end;}
  if(i+1<text.Length&&text[i]=='/'&&text[i+1]=='*'){int end=text.IndexOf("*/",i+2,StringComparison.Ordinal);return end<0?text.Length:end+2;}
  var raw=rawPrefix.Match(text,i);if(raw.Success){int p=text.IndexOf('(',i+raw.Length);if(p>=0&&p-i-raw.Length<=16){string end=")"+text.Substring(i+raw.Length,p-i-raw.Length)+"\"";int close=text.IndexOf(end,p+1,StringComparison.Ordinal);return close<0?text.Length:close+end.Length;}}
  if(text[i]=='\"'||text[i]=='\''){char quote=text[i++];while(i<text.Length){if(text[i]=='\\'){i=Math.Min(text.Length,i+2);continue;}if(text[i++]==quote)break;}return i;}return i;
 }
 public static bool InLiteral(string text,int caret){for(int i=0;i<caret;){int end=SkipLiteral(text,i);if(end>i){bool comment=i+1<text.Length&&text[i]=='/'&&text[i+1]=='/';bool unclosedBlock=i+1<text.Length&&text[i]=='/'&&text[i+1]=='*'&&!text.Substring(i,end-i).EndsWith("*/");bool unclosedQuote=(text[i]=='"'||text[i]=='\'')&&end==text.Length&&text[end-1]!=text[i];if(caret<end||(caret==end&&(comment||unclosedBlock||unclosedQuote)))return true;i=end;}else i++;}return false;}
 public static string Format(string source){
  source=source.Replace("\r\n","\n");var protectedText=new bool[source.Length];for(int i=0;i<source.Length;){int end=SkipLiteral(source,i);if(end>i){for(int p=i;p<end;p++)protectedText[p]=true;i=end;}else i++;}
  var lines=source.Split('\n');int depth=0;var b=new StringBuilder();int absolute=0;
  foreach(string line in lines){string trimmed=line.Trim();int leading=trimmed.StartsWith("}")?1:0;bool literal=absolute<protectedText.Length&&protectedText[absolute];if(literal)b.Append(line);else b.Append(new string(' ',Math.Max(0,depth-leading)*4)).Append(trimmed);
   for(int i=0;i<line.Length;i++){if(!protectedText[absolute+i]){if(line[i]=='{')depth++;else if(line[i]=='}')depth=Math.Max(0,depth-1);}}b.Append('\n');absolute+=line.Length+1;
  }return b.ToString().TrimEnd('\n')+"\n";
 }
 public static string EnterText(string text,int caret){int start=caret==0?-1:text.LastIndexOf('\n',caret-1);start=start<0?0:start+1;string prefix=text.Substring(start,caret-start);string indent=Regex.Match(prefix,@"^[ \t]*").Value.Replace("\t","    ");bool open=prefix.TrimEnd().EndsWith("{")&&!InLiteral(text,caret);return "\n"+indent+(open?"    ":"");}
}
public class CodeEditor:RichTextBox {
 class Snapshot{public string Text;public int Start,Length;}
 List<Snapshot> undo=new List<Snapshot>(),redo=new List<Snapshot>();string last="";int lastCaret,lastLength;bool restoring;public bool Styling {get;set;}public bool RtlMode {get;private set;}public event EventHandler HistoryChanged;
 public CodeEditor(){AcceptsTab=true;DetectUrls=false;WordWrap=false;EnableAutoDragDrop=false;Font=new Font("Consolas",14);SetDirection(true);var menu=new ContextMenuStrip();menu.Items.Add("تراجع",null,(s,e)=>Undo());menu.Items.Add("إعادة",null,(s,e)=>Redo());menu.Items.Add("قص",null,(s,e)=>Cut());menu.Items.Add("نسخ",null,(s,e)=>Copy());menu.Items.Add("لصق نص",null,(s,e)=>PastePlain());menu.Items.Add("تنسيق الكود",null,(s,e)=>FormatCode());ContextMenuStrip=menu;}
 public void ResetHistory(){undo.Clear();redo.Clear();last=Text;lastCaret=SelectionStart;lastLength=SelectionLength;}
 protected override void OnTextChanged(EventArgs e){if(!Styling&&Text!=last){if(!restoring){undo.Add(new Snapshot(){Text=last,Start=lastCaret,Length=lastLength});if(undo.Count>150)undo.RemoveAt(0);redo.Clear();}last=Text;lastCaret=SelectionStart;lastLength=SelectionLength;if(HistoryChanged!=null)HistoryChanged(this,EventArgs.Empty);base.OnTextChanged(e);}}
 protected override void OnSelectionChanged(EventArgs e){if(!Styling){lastCaret=SelectionStart;lastLength=SelectionLength;}base.OnSelectionChanged(e);}
 public new void Undo(){Restore(undo,redo);}public new void Redo(){Restore(redo,undo);}
 void Restore(List<Snapshot> from,List<Snapshot> to){if(from.Count==0)return;to.Add(new Snapshot(){Text=Text,Start=SelectionStart,Length=SelectionLength});var s=from[from.Count-1];from.RemoveAt(from.Count-1);restoring=true;try{Text=s.Text;Select(Math.Min(s.Start,TextLength),Math.Min(s.Length,Math.Max(0,TextLength-s.Start)));ScrollToCaret();}finally{restoring=false;}}
 public void SetDirection(bool rtl){RtlMode=rtl;Styling=true;int start=SelectionStart,len=SelectionLength;try{RightToLeft=rtl?RightToLeft.Yes:RightToLeft.No;if(IsHandleCreated){SelectAll();SelectionAlignment=rtl?HorizontalAlignment.Right:HorizontalAlignment.Left;Select(start,len);}}finally{Styling=false;}}
 public void FormatCode(){int line=GetLineFromCharIndex(SelectionStart);Text=CodeFormat.Format(Text);int start=GetFirstCharIndexFromLine(Math.Min(line,Lines.Length-1));Select(Math.Max(0,start),0);}
 void PastePlain(){if(Clipboard.ContainsText())SelectedText=CodeFormat.LatinDigits(Clipboard.GetText(TextDataFormat.UnicodeText));}
 protected override bool ProcessCmdKey(ref Message msg,Keys keys){if(keys==(Keys.Control|Keys.Z)){Undo();return true;}if(keys==(Keys.Control|Keys.Y)||keys==(Keys.Control|Keys.Shift|Keys.Z)){Redo();return true;}if(keys==(Keys.Control|Keys.V)){PastePlain();return true;}if(keys==(Keys.Control|Keys.Shift|Keys.F)){FormatCode();return true;}if(keys==Keys.Tab||keys==(Keys.Shift|Keys.Tab)){Indent(keys.HasFlag(Keys.Shift));return true;}return base.ProcessCmdKey(ref msg,keys);}
 void Indent(bool remove){if(SelectionLength==0&&!remove){SelectedText="    ";return;}int first=GetLineFromCharIndex(SelectionStart),lastLine=GetLineFromCharIndex(SelectionStart+SelectionLength);int a=GetFirstCharIndexFromLine(first),b=lastLine+1<Lines.Length?GetFirstCharIndexFromLine(lastLine+1):TextLength;string segment=Text.Substring(a,b-a);string changed=Regex.Replace(segment,remove?@"^(?: {1,4}|\t)":@"^(?=.)",remove?"":"    ",RegexOptions.Multiline);Select(a,b-a);SelectedText=changed;Select(a,changed.Length);}
 protected override void OnKeyPress(KeyPressEventArgs e){
  if(char.IsControl(e.KeyChar)&&e.KeyChar!='\r'){base.OnKeyPress(e);return;}
  e.KeyChar=CodeFormat.LatinDigits(e.KeyChar.ToString())[0];
  int caret=SelectionStart;string text=Text;
  if(e.KeyChar=='"'&&caret<text.Length&&text[caret]=='"'&&CodeFormat.InLiteral(text,caret)&&(caret==0||text[caret-1]!='\\')){Select(caret+1,0);e.Handled=true;return;}
  if(e.KeyChar=='\r'){string insertion=CodeFormat.EnterText(text,caret);bool pair=caret>0&&caret<text.Length&&text[caret-1]=='{'&&text[caret]=='}'&&!CodeFormat.InLiteral(text,caret);string extra=pair?"\n"+Regex.Match(insertion.Substring(1),@"^[ \t]*").Value.Substring(0,Math.Max(0,insertion.Length-1-4)):"";SelectedText=insertion+extra;Select(caret+insertion.Length,0);e.Handled=true;return;}
  if(!CodeFormat.InLiteral(text,caret)){
   string opens="([{\"",closes=")] }\"".Replace(" ","");int index=opens.IndexOf(e.KeyChar);
   if(index>=0){string selected=SelectedText;SelectedText=e.KeyChar+selected+closes[index];Select(caret+1,selected.Length);e.Handled=true;return;}
   if((e.KeyChar==')'||e.KeyChar==']'||e.KeyChar=='}')&&caret<text.Length&&text[caret]==e.KeyChar){Select(caret+1,0);e.Handled=true;return;}
   if(e.KeyChar=='}'){int start=text.LastIndexOf('\n',Math.Max(0,caret-1))+1;string prefix=text.Substring(start,caret-start);if(prefix.Trim().Length==0&&prefix.Length>=4){Select(start,prefix.Length);SelectedText=prefix.Substring(0,prefix.Length-4)+"}";e.Handled=true;return;}}
  }
  base.OnKeyPress(e);
 }
}
}
