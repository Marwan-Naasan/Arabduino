using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;
namespace Arabduino {
public static class FutureTheme {
 public static Color Background=Color.FromArgb(8,15,28),Surface=Color.FromArgb(15,26,43),Raised=Color.FromArgb(23,39,60),Line=Color.FromArgb(42,66,88),Text=Color.FromArgb(220,233,246),Muted=Color.FromArgb(140,162,185),Cyan=Color.FromArgb(66,223,212),Purple=Color.FromArgb(175,139,255);
 public static Brush TextBrush=new SolidBrush(Text),MutedBrush=new SolidBrush(Muted),CyanBrush=new SolidBrush(Cyan);
 public static string Name="فضاء زجاجي";public static readonly string[] Names={"فضاء زجاجي","محيط زجاجي","بنفسجي زجاجي","زمرد زجاجي"};
 public static bool DayMode;public static void SetDayMode(bool day){DayMode=day;Select(Name);}
 public static void Select(string name){if(Array.IndexOf(Names,name)<0)return;Name=name;Background=name==Names[1]?Color.FromArgb(4,24,36):name==Names[2]?Color.FromArgb(23,12,39):name==Names[3]?Color.FromArgb(6,28,25):Color.FromArgb(8,15,28);Surface=ControlPaint.Light(Background,0.10f);Raised=ControlPaint.Light(Background,0.23f);Line=ControlPaint.Light(Background,0.42f);Cyan=name==Names[2]?Color.FromArgb(210,162,255):name==Names[3]?Color.FromArgb(89,234,179):Color.FromArgb(66,223,212);Text=DayMode?Color.FromArgb(25,40,59):Color.FromArgb(220,233,246);Muted=DayMode?Color.FromArgb(77,98,121):Color.FromArgb(140,162,185);Purple=DayMode?Color.FromArgb(106,57,166):Color.FromArgb(175,139,255);if(DayMode){Background=Color.FromArgb(244,248,253);Surface=Color.FromArgb(233,241,250);Raised=Color.FromArgb(219,232,246);Line=Color.FromArgb(167,188,210);Cyan=name==Names[2]?Color.FromArgb(111,53,165):name==Names[3]?Color.FromArgb(15,115,79):Color.FromArgb(0,106,128);}TextBrush.Dispose();MutedBrush.Dispose();CyanBrush.Dispose();TextBrush=new SolidBrush(Text);MutedBrush=new SolidBrush(Muted);CyanBrush=new SolidBrush(Cyan);}
 class State{}static ConditionalWeakTable<Control,State> hooked=new ConditionalWeakTable<Control,State>();
 [DllImport("dwmapi.dll")]static extern int DwmSetWindowAttribute(IntPtr h,int attribute,ref int value,int size);
 public static void Apply(Control root){State state;if(!hooked.TryGetValue(root,out state)){hooked.Add(root,new State());root.ControlAdded+=(s,e)=>Apply(e.Control);if(root is Form){root.HandleCreated+=(s,e)=>DarkTitle((Form)root);if(root.IsHandleCreated)DarkTitle((Form)root);}}
  root.ForeColor=Text;if(root is Form&&root.IsHandleCreated)DarkTitle((Form)root);
  if(root is TextBox||root is ComboBox||root is NumericUpDown){GlassDesign.RoundControl(root);root.SizeChanged-=RoundChanged;root.SizeChanged+=RoundChanged;}
  if(root is CodeEditor){root.BackColor=Background;}
  else if(root is RichTextBox){root.BackColor=Surface;((RichTextBox)root).BorderStyle=BorderStyle.None;}
  else if(root is TextBox){root.BackColor=Raised;((TextBox)root).BorderStyle=BorderStyle.FixedSingle;}
  else if(root is ComboBox){root.BackColor=Raised;((ComboBox)root).FlatStyle=FlatStyle.Flat;}
  else if(root is NumericUpDown){root.BackColor=Raised;((NumericUpDown)root).BorderStyle=BorderStyle.FixedSingle;}
  else if(root is ListBox){root.BackColor=Surface;((ListBox)root).BorderStyle=BorderStyle.None;}
  else if(root is Button){var b=(Button)root;b.FlatStyle=FlatStyle.Flat;if(b.Name!="BlockPaletteButton")b.BackColor=Raised;b.ForeColor=Text;b.FlatAppearance.BorderColor=Line;b.FlatAppearance.MouseOverBackColor=Color.FromArgb(30,74,91);b.FlatAppearance.MouseDownBackColor=Color.FromArgb(27,99,111);b.FlatAppearance.BorderSize=1;b.Cursor=Cursors.Hand;}
  else if(root is ToolStrip){var strip=(ToolStrip)root;strip.BackColor=Surface;strip.Renderer=new GlassToolStripRenderer(new FutureColors()){RoundedEdges=false};foreach(ToolStripItem item in strip.Items)StyleItem(item);}
  else if(root is TabControl){var tabs=(TabControl)root;tabs.DrawMode=TabDrawMode.OwnerDrawFixed;tabs.SizeMode=TabSizeMode.Fixed;tabs.ItemSize=new Size(tabs.Name=="MainModes"?160:tabs.Name=="SimulatorModes"?76:128,36);tabs.Padding=new Point(12,6);if(tabs.Tag as string!="future-tabs"){tabs.Tag="future-tabs";tabs.DrawItem+=(s,e)=>{bool active=e.Index==tabs.SelectedIndex;var paintBounds=e.Bounds;bool mirrored=tabs.RightToLeftLayout&&tabs.RightToLeft==RightToLeft.Yes;if(mirrored)paintBounds.X=tabs.ClientSize.Width-e.Bounds.Right;int edge=0;for(int i=0;i<tabs.TabCount;i++)edge=Math.Max(edge,tabs.GetTabRect(i).Right);using(var unused=new SolidBrush(Surface))e.Graphics.FillRectangle(unused,new Rectangle(mirrored?0:edge,e.Bounds.Top,Math.Max(0,tabs.ClientSize.Width-edge),e.Bounds.Height));using(var fill=new SolidBrush(active?Raised:Surface))e.Graphics.FillRectangle(fill,paintBounds);if(active)using(var pen=new Pen(Cyan,3))e.Graphics.DrawLine(pen,paintBounds.Left+6,paintBounds.Bottom-2,paintBounds.Right-6,paintBounds.Bottom-2);TextRenderer.DrawText(e.Graphics,tabs.TabPages[e.Index].Text,tabs.Font,e.Bounds,active?Cyan:Muted,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);};}}
  else if(root is Label){root.BackColor=Color.Transparent;root.ForeColor=(root.Name=="BlockLabel"||(root.Parent!=null&&(root.Parent.Name=="BlockFields"||root.Parent.Name=="BlockHeader"||root.Parent.Name=="BlockCard")))?Color.White:(root.Font.Bold?Cyan:Text);}
  else if(root.Name=="BlockFields"){root.BackColor=Color.Transparent;}
  else if(root.Name=="BlockCavity"){root.BackColor=Background;}
  else if(root.Name!="BlockCard"&&root.Name!="BlockHeader"){root.BackColor=root is TabPage||root is Form?Background:Surface;}
  if(root.Parent!=null&&root.Parent.Name=="BlockFields"&&(root is TextBox||root is ComboBox)){root.BackColor=Color.FromArgb(244,249,255);root.ForeColor=Color.FromArgb(27,47,63);}
  foreach(Control child in root.Controls)Apply(child);if(root is LearningPanel)((LearningPanel)root).RefreshTheme();if(root is CodeEditor)Highlight.Paint((CodeEditor)root);root.Invalidate();
 }
 static void RoundChanged(object sender,EventArgs e){GlassDesign.RoundControl((Control)sender);}
 static void DarkTitle(Form form){try{int enabled=DayMode?0:1;DwmSetWindowAttribute(form.Handle,20,ref enabled,4);}catch{}}
 static void StyleItem(ToolStripItem item){item.ForeColor=Text;if(item is ToolStripMenuItem)foreach(ToolStripItem child in ((ToolStripMenuItem)item).DropDownItems)StyleItem(child);}
 class FutureColors:ProfessionalColorTable {
  public override Color ToolStripDropDownBackground {get{return Surface;}}public override Color MenuItemSelected {get{return Raised;}}public override Color MenuItemBorder {get{return Cyan;}}public override Color MenuBorder {get{return Line;}}public override Color MenuStripGradientBegin {get{return Surface;}}public override Color MenuStripGradientEnd {get{return Surface;}}public override Color ToolStripGradientBegin {get{return Surface;}}public override Color ToolStripGradientMiddle {get{return Surface;}}public override Color ToolStripGradientEnd {get{return Surface;}}public override Color ImageMarginGradientBegin {get{return Surface;}}public override Color ImageMarginGradientMiddle {get{return Surface;}}public override Color ImageMarginGradientEnd {get{return Surface;}}public override Color ButtonSelectedGradientBegin {get{return Raised;}}public override Color ButtonSelectedGradientMiddle {get{return Raised;}}public override Color ButtonSelectedGradientEnd {get{return Raised;}}public override Color SeparatorDark {get{return Line;}}
 }
}
public class FutureHeader:Control {
 public FutureHeader(){Height=78;Dock=DockStyle.Top;DoubleBuffered=true;}
 protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;using(var brush=new LinearGradientBrush(ClientRectangle,FutureTheme.Raised,FutureTheme.Background,LinearGradientMode.Horizontal))g.FillRectangle(brush,ClientRectangle);using(var pen=new Pen(FutureTheme.Line))for(int x=0;x<Width;x+=36)g.DrawLine(pen,x,0,x-36,Height);using(var pen=new Pen(FutureTheme.Cyan,2))g.DrawLine(pen,0,Height-1,Width,Height-1);using(var logo=new Font("Consolas",24,FontStyle.Bold))g.DrawString("{ ع }",logo,FutureTheme.CyanBrush,20,18);using(var title=new Font("Segoe UI",20,FontStyle.Bold))g.DrawString("ARABDUINO",title,FutureTheme.TextBrush,126,10);using(var font=new Font("Segoe UI",9))g.DrawString("1.5  /  CODE · BLOCKS · LEARN · SIMULATE",font,FutureTheme.MutedBrush,129,44);using(var credit=new Font("Segoe UI",10,FontStyle.Regular))g.DrawString("by Marwan Nasan",credit,FutureTheme.TextBrush,Width-205,53);using(var font=new Font("Segoe UI",13,FontStyle.Bold))TextRenderer.DrawText(g,"اكتب فكرتك. ابنِ دارتك. تعلّم بالعربي.",font,new Rectangle(Width-510,16,480,44),FutureTheme.Text,TextFormatFlags.Right|TextFormatFlags.VerticalCenter|TextFormatFlags.RightToLeft);}
}
public class SnapZone:Panel {
 public bool Highlighted;public SnapZone(){DoubleBuffered=true;Height=18;Margin=new Padding(12,1,12,4);Cursor=Cursors.Hand;}
 protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);using(var pen=new Pen(Highlighted?FutureTheme.Cyan:FutureTheme.Line,Highlighted?3:1){DashStyle=Highlighted?DashStyle.Solid:DashStyle.Dot})e.Graphics.DrawLine(pen,8,Height/2,Width-8,Height/2);if(Highlighted)e.Graphics.FillEllipse(FutureTheme.CyanBrush,Width/2-5,Height/2-5,10,10);}
}
public class PuzzleCard:FlowLayoutPanel {
 public PuzzleCard(){DoubleBuffered=true;Name="BlockCard";SetStyle(ControlStyles.ResizeRedraw,true);Padding=new Padding(6,14,16,12);}
 public bool Hat;protected override void OnSizeChanged(EventArgs e){base.OnSizeChanged(e);if(Width>1&&Height>1)using(var path=GlassDesign.Stack(Width,Height,Hat,false)){var old=Region;Region=new Region(path);if(old!=null)old.Dispose();}}
 protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;using(var path=GlassDesign.Stack(Width,Height,Hat,false))using(var pen=new Pen(Color.FromArgb(95,Color.White)))e.Graphics.DrawPath(pen,path);}
}
public class DragBadge:Form {
 protected override bool ShowWithoutActivation {get{return true;}}
 protected override CreateParams CreateParams {get{var p=base.CreateParams;p.ExStyle|=0x080000A0;return p;}}
 public DragBadge(string title){FormBorderStyle=FormBorderStyle.None;ShowInTaskbar=false;TopMost=true;StartPosition=FormStartPosition.Manual;Size=new Size(220,44);BackColor=FutureTheme.Raised;Opacity=0.92;Controls.Add(new Label(){Text="⋮⋮  "+title,Dock=DockStyle.Fill,ForeColor=FutureTheme.Cyan,TextAlign=ContentAlignment.MiddleCenter,Font=new Font("Segoe UI",11,FontStyle.Bold)});}
}
}
