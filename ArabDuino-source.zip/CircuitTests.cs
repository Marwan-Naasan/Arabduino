using System;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.IO;
using System.Runtime.Serialization.Json;
using Arabduino;
class CircuitTests {
 static int count;
 static void Check(bool value,string name){if(!value)throw new Exception(name);count++;}
 [STAThread]static void Main(){
 using(var lab=new Simulator(()=>Translator.Blink,s=>{}))using(var bitmap=new Bitmap(1000,650))using(var graphics=Graphics.FromImage(bitmap)){
  Func<Circuit> circuit=()=>(Circuit)typeof(Simulator).GetField("circuit",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(lab);
  Action<string> preset=name=>typeof(Simulator).GetMethod("Preset",BindingFlags.NonPublic|BindingFlags.Instance).Invoke(lab,new object[]{name,false});
  Action draw=()=>lab.Draw(graphics,new Rectangle(0,0,1000,650));
  lab.Write(13,1,false);draw();Check(circuit().Parts.First(p=>p.Kind=="LED").Level==1,"Wired LED high");lab.Write(13,0,false);draw();Check(circuit().Parts.First(p=>p.Kind=="LED").Level==0,"Wired LED low");
  lab.Write(13,1,false);circuit().Wires.RemoveAll(w=>w.A=="led.-"||w.B=="led.-");draw();Check(circuit().Parts.First(p=>p.Kind=="LED").Level==0,"Disconnected LED must be off");
  preset("زر وLED");lab.Mode(2,2);Check(lab.Read(2,false)==1,"Button released pullup");circuit().Parts.First(p=>p.Kind=="زر").Pressed=true;Check(lab.Read(2,false)==0,"Button pressed ground");
  preset("سطوع تماثلي");var pot=circuit().Parts.First(p=>p.Kind=="مقاومة متغيرة");pot.Value=900;Check(lab.Read(14,true)==900,"Pot analog input");circuit().Wires.RemoveAll(w=>w.A=="pot.5V"||w.B=="pot.5V");Check(lab.Read(14,true)==0,"Unpowered sensor");
  preset("حركة سيرفو");lab.Servo(9,75);draw();Check(circuit().Parts.First(p=>p.Kind=="سيرفو").Level==75,"Servo follows signal");
  using(var stream=new MemoryStream()){var serializer=new DataContractJsonSerializer(typeof(Circuit));serializer.WriteObject(stream,circuit());stream.Position=0;var restored=(Circuit)serializer.ReadObject(stream);Check(restored.Parts.Count==1&&restored.Wires.Count==3,"Circuit save roundtrip");}
 }
 Console.WriteLine("PASS: "+count+" circuit interaction checks");
 }
}
