using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Arabduino {
[DataContract] public class Part {
 [DataMember] public string Id,Kind;[DataMember]public int X,Y,Value=512,Secondary=512,Rotation; [DataMember]public string Label; public bool Active,Triggered,DisplayHidden;public double[] Channels=new double[12];public string[] DisplayLines={"",""};public int CursorX,CursorY;
 public bool Pressed;public double Level;
 public string[] Pins {get{return PartCatalog.Names(this);}}
}
[DataContract]public class Wire { [DataMember]public string A,B;[DataMember]public int ColorArgb;[DataMember]public List<CircuitPoint> Bends=new List<CircuitPoint>(); }
[DataContract]public class Circuit { [DataMember]public List<Part> Parts=new List<Part>();[DataMember]public List<Wire> Wires=new List<Wire>(); }
class CircuitCanvas:Control {
 public Simulator Lab; public CircuitCanvas(){DoubleBuffered=true;Dock=DockStyle.Fill;BackColor=Color.FromArgb(245,248,251);}
 protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);Lab.Draw(e.Graphics,ClientRectangle);}
 protected override void OnMouseDown(MouseEventArgs e){base.OnMouseDown(e);Focus();Lab.Down(e);}
 protected override void OnMouseMove(MouseEventArgs e){base.OnMouseMove(e);Lab.DragMove(e);}
 protected override void OnMouseUp(MouseEventArgs e){base.OnMouseUp(e);Lab.Up();}
 protected override void OnMouseWheel(MouseEventArgs e){Lab.Zoom(e.Delta>0?1.15f:1/1.15f,e.Location);}
 protected override void OnKeyDown(KeyEventArgs e){base.OnKeyDown(e);Lab.CanvasKey(e);}
}
public partial class Simulator:Form,IVirtualBoard,IVirtualFeatures {
 Circuit circuit=new Circuit(); CircuitCanvas canvas=new CircuitCanvas();RichTextBox terminal=new RichTextBox();Label state=new Label(),selection=new Label();TrackBar value=new TrackBar();ComboBox speed=new ComboBox();
 Func<string> source;Action<string> example;CancellationTokenSource cancellation;VirtualMachine machine;bool running;string pending;Part selected,dragged,pressed;Point offset;Dictionary<int,double> outputs=new Dictionary<int,double>();Dictionary<int,int> modes=new Dictionary<int,int>();Dictionary<int,double> angles=new Dictionary<int,double>();
 readonly Font normal=new Font("Segoe UI",9),bold=new Font("Segoe UI",10,FontStyle.Bold),big=new Font("Segoe UI",22,FontStyle.Bold);readonly Font pinFont=new Font("Segoe UI",8);System.Windows.Forms.Timer refresh=new System.Windows.Forms.Timer();
 public Simulator(Func<string> code,Action<string> setExample){source=code;example=setExample;Text="Arabduino • مختبر المحاكاة";Size=new Size(1220,840);MinimumSize=new Size(1000,700);StartPosition=FormStartPosition.CenterParent;Font=new Font("Segoe UI",10);BackColor=Color.White;
  var top=new FlowLayoutPanel(){Dock=DockStyle.Top,Height=56,Padding=new Padding(8),BackColor=Color.FromArgb(0,125,128),RightToLeft=RightToLeft.Yes,WrapContents=false};
  Action<string,EventHandler> button=(text,action)=>{var b=new GlassButton(){Text=text,AutoSize=true,Height=32,BackColor=Color.White,FlatStyle=FlatStyle.Flat};b.Click+=action;top.Controls.Add(b);};
  button("▶ تشغيل",async(s,e)=>await Start());button("Ⅱ إيقاف مؤقت",(s,e)=>{if(machine!=null){machine.Paused=!machine.Paused;state.Text=machine.Paused?"متوقفة مؤقتاً":"المحاكاة تعمل";}});button("■ إيقاف",(s,e)=>Stop());button("حفظ الدارة",(s,e)=>SaveCircuit());button("فتح دارة",(s,e)=>LoadCircuit());button("دليل المحاكاة",(s,e)=>Guide());speed.DropDownStyle=ComboBoxStyle.DropDownList;speed.Width=75;speed.Items.AddRange(new object[]{"0.5×","1×","2×","5×"});speed.SelectedIndex=1;speed.SelectedIndexChanged+=(s,e)=>{if(machine!=null)machine.Speed=new[]{0.5,1,2,5}[speed.SelectedIndex];};top.Controls.Add(speed);
  var side=new FlowLayoutPanel(){Dock=DockStyle.Right,Width=215,Padding=new Padding(10),FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoScroll=true,BackColor=Color.White,RightToLeft=RightToLeft.Yes};side.Controls.Add(new Label(){Text="العناصر",Font=bold,Width=185,Height=30});
  foreach(string kind in new[]{"LED","مقاومة","زر","مقاومة متغيرة","سيرفو"}){string k=kind;var b=new GlassButton(){Text="+ "+kind,Width=182,Height=36,FlatStyle=FlatStyle.Flat};b.Click+=(s,e)=>{if(!Editable())return;var part=new Part(){Id="p"+Guid.NewGuid().ToString("N").Substring(0,8),Kind=k,X=440+circuit.Parts.Count%3*115,Y=90+circuit.Parts.Count/3*125,Value=k=="مقاومة"?220:512};circuit.Parts.Add(part);Select(part);canvas.Invalidate();};side.Controls.Add(b);}
  side.Controls.Add(new Label(){Text="دارات جاهزة + الكود",Font=bold,Width=185,Height=40,Padding=new Padding(0,12,0,0)});
  foreach(string preset in new[]{"وميض LED","زر وLED","سطوع تماثلي","حركة سيرفو"}){string name=preset;var b=new GlassButton(){Text=name,Width=182,Height=33};b.Click+=(s,e)=>{if(!Editable())return;Preset(name,true);};side.Controls.Add(b);}
  selection.Text="اختر عنصراً لتعديل قيمته";selection.Width=185;selection.Height=55;side.Controls.Add(selection);value.Minimum=0;value.Maximum=1023;value.Width=180;value.TickFrequency=256;value.ValueChanged+=(s,e)=>{if(selected!=null){selected.Value=value.Value;selection.Text=selected.Kind+" • "+selected.Value+(selected.Kind=="مقاومة"?" Ω":"");canvas.Invalidate();}};side.Controls.Add(value);
  var remove=new GlassButton(){Text="حذف العنصر المحدد",Width=182,Height=35};remove.Click+=(s,e)=>{if(selected==null||!Editable())return;string id=selected.Id;circuit.Parts.Remove(selected);circuit.Wires.RemoveAll(w=>w.A.StartsWith(id+".")||w.B.StartsWith(id+"."));selected=null;canvas.Invalidate();};side.Controls.Add(remove);
  var clearWires=new GlassButton(){Text="مسح الأسلاك",Width=182,Height=32};clearWires.Click+=(s,e)=>{if(!Editable())return;circuit.Wires.Clear();pending=null;canvas.Invalidate();};side.Controls.Add(clearWires);
  side.Controls.Add(new Label(){Text="انقر طرفاً ثم طرفاً آخر للتوصيل.\nاسحب العنصر من اسمه.\nاضغط الزر أثناء التشغيل.\nحرّك المنزلق لتغيير دخل الحساس.\nالتوصيلات تتغير عند إيقاف المحاكاة.",Width=185,Height=140,ForeColor=Color.DimGray});
  terminal.Dock=DockStyle.Bottom;terminal.Height=130;terminal.ReadOnly=true;terminal.Font=new Font("Consolas",10);terminal.BackColor=Color.FromArgb(25,37,47);terminal.ForeColor=Color.FromArgb(210,237,230);state.Dock=DockStyle.Bottom;state.Height=30;state.TextAlign=ContentAlignment.MiddleRight;state.BackColor=Color.FromArgb(228,242,240);state.Text="جاهز • محاكاة تعليمية محلية، بدون لوحة أو إنترنت";
  canvas.Lab=this;Controls.Add(canvas);Controls.Add(side);Controls.Add(terminal);Controls.Add(state);Controls.Add(top);Preset("وميض LED",false);
  refresh.Interval=40;refresh.Tick+=(s,e)=>canvas.Invalidate();refresh.Start();UpgradeUI(side,top);FutureTheme.Apply(this);FormClosing+=(s,e)=>{Stop();refresh.Stop();};
 }
 bool Editable(){if(!running)return true;state.Text="أوقف المحاكاة أولاً لتعديل التوصيلات.";return false;}
 void Select(Part p){selected=p;if(p!=null){selection.Text=p.Kind+" • "+p.Value;value.Value=Math.Max(0,Math.Min(1023,p.Value));value.Enabled=p.Kind=="مقاومة متغيرة"||p.Kind=="مقاومة";}canvas.Invalidate();}
 public async Task Start(){if(running)return;Stop();ResetExtended();outputs.Clear();modes.Clear();angles.Clear();terminal.Clear();cancellation=new CancellationTokenSource();var thisRun=cancellation;machine=new VirtualMachine(this){Speed=new[]{0.5,1,2,5}[speed.SelectedIndex]};running=true;state.Text="المحاكاة تعمل • تغييرات الكود تظهر بعد الإيقاف وإعادة التشغيل";try{await machine.Run(source(),cancellation.Token);}catch(OperationCanceledException){}catch(Exception ex){Print("\nالمحاكاة توقفت: "+ex.Message+"\n");state.Text="صيغة أو دالة غير مدعومة • راجع السجل ودليل المحاكاة";}finally{if(ReferenceEquals(cancellation,thisRun)){running=false;canvas.Invalidate();}}}
 void Stop(){ClearTones();if(cancellation!=null)cancellation.Cancel();if(machine!=null)machine.Paused=false;running=false;state.Text="متوقفة • يمكنك تعديل الدارة ثم تشغيل الكود الحالي";pending=null;}
 Dictionary<string,Point> Pins(){var p=new Dictionary<string,Point>();for(int i=0;i<14;i++)p["board.D"+i]=new Point(65+i*23,112);for(int i=0;i<6;i++)p["board.A"+i]=new Point(190+i*25,350);p["board.5V"]=new Point(65,350);p["board.GND"]=new Point(110,350);foreach(var part in circuit.Parts)foreach(var pin in PartCatalog.Pins(part))p[pin.Key]=pin.Value;return p;}
 HashSet<string> Net(string start){return new CircuitGraph(circuit).Connected(start);}
 bool Powered(Part p){return Net(p.Id+".5V").Contains("board.5V")&&Net(p.Id+".GND").Contains("board.GND");}
 string Pin(int n){if(n<0||n>19)throw new Exception("المحاكي يدعم D0..D13 وA0..A5 فقط.");return "board."+(n<14?"D"+n:"A"+(n-14));}
 public double ReadLegacy(int pin,bool analog){if(analog&&pin<6)pin+=14;var net=Net(Pin(pin));if(net.Contains("board.GND"))return 0;if(net.Contains("board.5V"))return analog?1023:1;foreach(var p in circuit.Parts)if(p.Kind=="مقاومة متغيرة"&&net.Contains(p.Id+".OUT")&&Powered(p))return analog?p.Value:(p.Value>511?1:0);double v;if(outputs.TryGetValue(pin,out v))return analog?v*1023:(v>0.5?1:0);int mode;return modes.TryGetValue(pin,out mode)&&mode==2?(analog?1023:1):0;}
 public void WriteLegacy(int pin,double val,bool analog){Pin(pin);outputs[pin]=Math.Max(0,Math.Min(1,analog?val/255:(val==0?0:1)));if(outputs[pin]>0&&Net(Pin(pin)).Contains("board.GND"))throw new Exception("قصر منطقي: خرج مرتفع موصول بالأرضي. أوقف التشغيل وأصلح التوصيل.");}
 public void Mode(int pin,int mode){Pin(pin);modes[pin]=mode;}
 public void Servo(int pin,double angle){Pin(pin);angles[pin]=Math.Max(0,Math.Min(180,angle));}
 public void Print(string text){if(terminal.TextLength>60000)terminal.Clear();terminal.AppendText(text);terminal.SelectionStart=terminal.TextLength;terminal.ScrollToCaret();}
 double Output(HashSet<string> net){if(net.Contains("board.5V"))return 1;double result=0;foreach(var kv in outputs)if(net.Contains(Pin(kv.Key)))result=Math.Max(result,kv.Value);return result;}
 public void DrawLegacy(Graphics g,Rectangle bounds){
  g.SmoothingMode=SmoothingMode.AntiAlias;using(var dots=new SolidBrush(Color.FromArgb(215,225,233)))for(int x=15;x<bounds.Width;x+=22)for(int y=15;y<bounds.Height;y+=22)g.FillEllipse(dots,x,y,2,2);
  var pins=Pins();foreach(var w in circuit.Wires){Point a,b;if(pins.TryGetValue(w.A,out a)&&pins.TryGetValue(w.B,out b)){Color color=w.A.Contains("GND")||w.B.Contains("GND")?Color.FromArgb(61,72,87):w.A.Contains("5V")||w.B.Contains("5V")?Color.FromArgb(212,79,84):Color.FromArgb(225,153,43);using(var pen=new Pen(color,3)){g.DrawLine(pen,a,new Point(a.X,a.Y+(b.Y-a.Y)/2));g.DrawLine(pen,new Point(a.X,a.Y+(b.Y-a.Y)/2),new Point(b.X,a.Y+(b.Y-a.Y)/2));g.DrawLine(pen,new Point(b.X,a.Y+(b.Y-a.Y)/2),b);}}}
  using(var boardBrush=new SolidBrush(Color.FromArgb(0,113,137)))g.FillRectangle(boardBrush,40,100,350,265);g.DrawString("UNO",big,Brushes.White,160,170);g.DrawString("ARABDUINO • VIRTUAL",normal,Brushes.White,120,213);g.FillRectangle(Brushes.Silver,32,170,58,70);g.FillRectangle(Brushes.DimGray,123,260,210,36);g.FillRectangle(Brushes.Black,45,280,45,50);
  double led;outputs.TryGetValue(13,out led);g.FillEllipse(led>0?Brushes.Gold:Brushes.DarkSlateGray,335,180,15,15);g.DrawString("L13",normal,Brushes.White,328,200);
  // Redraw over the board so every wire can be traced back to its actual terminal.
  foreach(var w in circuit.Wires){Point a,b;if(pins.TryGetValue(w.A,out a)&&pins.TryGetValue(w.B,out b)){Color color=w.A.Contains("GND")||w.B.Contains("GND")?Color.FromArgb(61,72,87):w.A.Contains("5V")||w.B.Contains("5V")?Color.FromArgb(212,79,84):Color.FromArgb(225,153,43);using(var pen=new Pen(color,3)){int mid=a.Y+(b.Y-a.Y)/2;g.DrawLine(pen,a,new Point(a.X,mid));g.DrawLine(pen,new Point(a.X,mid),new Point(b.X,mid));g.DrawLine(pen,new Point(b.X,mid),b);}}}
  foreach(var part in circuit.Parts){int x=part.X,y=part.Y;using(var fill=new SolidBrush(selected==part?Color.FromArgb(225,240,248):Color.White))g.FillRectangle(fill,x,y,108,100);using(var border=new Pen(selected==part?Color.Teal:Color.FromArgb(190,207,218),selected==part?2:1))g.DrawRectangle(border,x,y,108,100);g.DrawString(part.Kind,bold,Brushes.DarkSlateGray,x+8,y+5);
   if(part.Kind=="LED"){var positive=Net(part.Id+".+");var negative=Net(part.Id+".-");double brightness=negative.Contains("board.GND")?Output(positive):0;part.Level=brightness;int red=(int)(90+165*brightness);using(var brush=new SolidBrush(Color.FromArgb(red,brightness>0?60:30,brightness>0?54:30)))g.FillEllipse(brush,x+37,y+32,34,34);g.DrawString(brightness>0?"ON "+(int)(brightness*100)+"%":"OFF",normal,Brushes.DimGray,x+22,y+58);}
   else if(part.Kind=="مقاومة"){g.FillRectangle(Brushes.BurlyWood,x+22,y+38,64,19);g.FillRectangle(Brushes.SaddleBrown,x+33,y+38,5,19);g.FillRectangle(Brushes.Red,x+46,y+38,5,19);g.FillRectangle(Brushes.Goldenrod,x+72,y+38,5,19);g.DrawString(part.Value+" Ω",normal,Brushes.DimGray,x+28,y+58);}
   else if(part.Kind=="زر"){g.FillRectangle(Brushes.DarkSlateGray,x+29,y+29,50,40);g.FillEllipse(part.Pressed?Brushes.Orange:Brushes.Gray,x+39,y+33,30,30);g.DrawString(part.Pressed?"PRESSED":"HOLD",normal,Brushes.DimGray,x+23,y+58);}
   else if(part.Kind=="مقاومة متغيرة"){g.FillEllipse(Brushes.Teal,x+36,y+31,36,36);double angle=part.Value/1023.0*270-135;float dx=(float)(Math.Sin(angle*Math.PI/180)*14),dy=(float)(-Math.Cos(angle*Math.PI/180)*14);g.DrawLine(Pens.White,x+54,y+49,x+54+dx,y+49+dy);g.DrawString(part.Value.ToString(),normal,Brushes.DimGray,x+35,y+58);}
   else {double angle=0;if(Powered(part)){var net=Net(part.Id+".SIG");foreach(var kv in angles)if(net.Contains(Pin(kv.Key)))angle=kv.Value;}part.Level=angle;g.FillRectangle(Brushes.RoyalBlue,x+25,y+33,60,35);using(var arm=new Pen(Color.White,5))g.DrawLine(arm,x+55,y+42,x+55+(float)(Math.Cos((angle-90)*Math.PI/180)*30),y+42+(float)(Math.Sin((angle-90)*Math.PI/180)*30));g.DrawString((int)angle+"°",normal,Brushes.DimGray,x+35,y+58);}
  }
  foreach(var kv in pins){bool board=kv.Key.StartsWith("board.");string name=kv.Key.Substring(kv.Key.IndexOf('.')+1);Point p=kv.Value;g.FillEllipse(pending==kv.Key?Brushes.OrangeRed:Brushes.DimGray,p.X-5,p.Y-5,10,10);g.DrawString(name,pinFont,board?Brushes.White:Brushes.Black,p.X-8,p.Y+(board&&p.Y==112?9:-13));}
  g.DrawString(pending==null?"انقر طرفاً ثم طرفاً آخر لرسم سلك • اسحب العنصر من اسمه":"اختر الطرف الثاني • النقر على الطرف نفسه يلغي التوصيل",normal,Brushes.DimGray,20,20);
  if(circuit.Parts.Any(p=>p.Kind=="LED"&&p.Level>0&&!Net(p.Id+".+").Any(n=>circuit.Parts.Any(r=>r.Kind=="مقاومة"&&n.StartsWith(r.Id+".")))))g.DrawString("تنبيه: LED مضاء بدون مقاومة تسلسلية. أضف مقاومة 220 Ω على الدارة الحقيقية.",normal,Brushes.Firebrick,20,48);
 }
 public void DownLegacy(MouseEventArgs e){
  if(e.Button==MouseButtons.Right){pending=null;canvas.Invalidate();return;}
  var hit=Pins().FirstOrDefault(kv=>Math.Abs(kv.Value.X-e.X)<10&&Math.Abs(kv.Value.Y-e.Y)<10);
  if(hit.Key!=null){if(!Editable())return;if(pending==null)pending=hit.Key;else{if(pending!=hit.Key&&!circuit.Wires.Any(w=>(w.A==pending&&w.B==hit.Key)||(w.B==pending&&w.A==hit.Key)))circuit.Wires.Add(new Wire(){A=pending,B=hit.Key});pending=null;}canvas.Invalidate();return;}
  var part=circuit.Parts.LastOrDefault(p=>new Rectangle(p.X,p.Y,108,100).Contains(e.Location));Select(part);if(part==null)return;
  if(part.Kind=="زر"&&e.Y>part.Y+26&&e.Y<part.Y+75){part.Pressed=true;pressed=part;canvas.Capture=true;canvas.Invalidate();return;}
  if(!running){dragged=part;offset=new Point(e.X-part.X,e.Y-part.Y);canvas.Capture=true;}
 }
 public void DragMoveLegacy(MouseEventArgs e){if(dragged!=null){dragged.X=Math.Max(10,Math.Min(canvas.Width-115,e.X-offset.X));dragged.Y=Math.Max(70,Math.Min(canvas.Height-110,e.Y-offset.Y));canvas.Invalidate();}}
 public void UpLegacy(){if(pressed!=null)pressed.Pressed=false;pressed=null;dragged=null;canvas.Capture=false;canvas.Invalidate();}
 void Connect(string a,string b){circuit.Wires.Add(new Wire(){A=a,B=b});}
 void Preset(string name,bool updateCode){if(!new[]{"وميض LED","زر وLED","سطوع تماثلي","حركة سيرفو"}.Contains(name)){PresetAdvanced(name,updateCode);return;}circuit=new Circuit();pending=null;selected=null;outputs.Clear();modes.Clear();angles.Clear();
  if(name!="حركة سيرفو") {circuit.Parts.Add(new Part(){Id="led",Kind="LED",X=470,Y=110});circuit.Parts.Add(new Part(){Id="r",Kind="مقاومة",X=470,Y=255,Value=220});Connect("led.-","board.GND");Connect("led.+","r.B");Connect("r.A",name=="سطوع تماثلي"?"board.D9":"board.D13");}
  string key="أساسيات • وميض المصباح";
  if(name=="زر وLED"){circuit.Parts.Add(new Part(){Id="button",Kind="زر",X=620,Y=150});Connect("button.A","board.D2");Connect("button.B","board.GND");key="إدخال • زر يشغّل LED";}
  if(name=="سطوع تماثلي"){circuit.Parts.Add(new Part(){Id="pot",Kind="مقاومة متغيرة",X=640,Y=160});Connect("pot.5V","board.5V");Connect("pot.GND","board.GND");Connect("pot.OUT","board.A0");key="تماثلي • مقاومة متغيرة وLED";}
  if(name=="حركة سيرفو"){circuit.Parts.Add(new Part(){Id="servo",Kind="سيرفو",X=490,Y=160});Connect("servo.5V","board.5V");Connect("servo.GND","board.GND");Connect("servo.SIG","board.D9");key="مكتبة Servo • حركة سيرفو";}
  if(updateCode)example(Examples.All[key]);canvas.Invalidate();
 }
 void SaveCircuit(){using(var d=new SaveFileDialog(){Filter="Arabduino circuit|*.arcircuit",FileName="circuit.arcircuit"})if(d.ShowDialog()==DialogResult.OK)try{using(var stream=File.Create(d.FileName))new DataContractJsonSerializer(typeof(Circuit)).WriteObject(stream,circuit);}catch(Exception ex){MessageBox.Show(ex.Message);}}
 void LoadCircuit(){if(!Editable())return;using(var d=new OpenFileDialog(){Filter="Arabduino circuit|*.arcircuit"})if(d.ShowDialog()==DialogResult.OK)try{if(new FileInfo(d.FileName).Length>4000000)throw new Exception("ملف كبير جداً.");var loaded=Deserialize(File.ReadAllText(d.FileName));Checkpoint();circuit=loaded;selected=null;selectedWire=null;Fit();}catch(Exception ex){MessageBox.Show(ex.Message,"تعذر فتح الدارة");}}
 void GuideLegacy(){MessageBox.Show("مختبر Arabduino المحلي\n\nابدأ بدارة جاهزة من القائمة. ستوضع العناصر والأسلاك والكود. اضغط تشغيل؛ لا تحتاج Arduino أو الإنترنت.\nأضف العناصر، انقر طرفين لرسم سلك، واسحب العنصر من عنوانه. احفظ الدارة مستقلة بصيغة .arcircuit واحفظ الكود من المحرر.\nLED يحتاج أرضياً ومصدراً للإشارة. المقاومة المتغيرة والسيرفو يحتاجان 5V وGND وإشارة. اضغط الزر باستمرار لتجربته، وحرّك منزلق المقاومة المتغيرة لتعديل الدخل.\n\nالمحاكي ينفذ مجموعة تعليمية من C++: متغيرات عددية، حسابات، if/else وfor وwhile وSerial وdelay وpinMode وdigitalRead/Write وanalogRead/Write وmap وServo.\nغير مدعوم: مصفوفات ومؤشرات ودوال مخصصة ومكتبات LCD وI2C وEEPROM والمقاطعات.\nالمحاكاة منطقية تعليمية، وليست محاكاة AVR أو SPICE: لا تحسب التيار والجهد أو احتراق القطع، ودقة التوقيت والأنواع العددية تقريبية. العمليات المنطقية تقيم الطرفين؛ تجنب آثاراً جانبية في شروطها.\nتغيير الكود يتطلب إيقافاً وإعادة تشغيل. دعم المكتبة على اللوحة الحقيقية مستقل عن دعمها بالمحاكي.","دليل المحاكاة",MessageBoxButtons.OK,MessageBoxIcon.Information);}
}
}
