using System.Reflection;
[assembly:AssemblyTitle("Arabduino")]
[assembly:AssemblyDescription("Arabic Arduino editor, visual blocks and educational circuit simulation")]
[assembly:AssemblyProduct("Arabduino")]
[assembly:AssemblyVersion("1.5.0.0")]
[assembly:AssemblyFileVersion("1.5.0.0")]
