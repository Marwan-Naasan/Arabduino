using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
namespace Arabduino {
public static class GlassDesign {
 public static GraphicsPath Round(RectangleF r,float radius){var p=new GraphicsPath();float d=Math.Min(radius*2,Math.Min(r.Width,r.Height));if(d<1){p.AddRectangle(r);return p;}p.AddArc(r.X,r.Y,d,d,180,90);p.AddArc(r.Right-d,r.Y,d,d,270,90);p.AddArc(r.Right-d,r.Bottom-d,d,d,0,90);p.AddArc(r.X,r.Bottom-d,d,d,90,90);p.CloseFigure();return p;}
 public static GraphicsPath Hex(int w,int h){var p=new GraphicsPath();p.AddPolygon(new[]{new Point(0,h/2),new Point(12,0),new Point(w-12,0),new Point(w,h/2),new Point(w-12,h),new Point(12,h)});return p;}
 public static void RoundControl(Control c){if(c.Width<2||c.Height<2)return;using(var p=c.Tag as string=="condition"?Hex(c.Width,c.Height):Round(new RectangleF(0,0,c.Width,c.Height),c is TextBox?10:14)){var old=c.Region;c.Region=new Region(p);if(old!=null)old.Dispose();}}
 public static GraphicsPath Stack(int width,int height,bool hat,bool reporter){if(reporter)return Round(new RectangleF(0,0,width-1,height-1),height/2f);float w=width-1,h=height-1,n=Math.Max(28,w-76);var p=new GraphicsPath();p.StartFigure();if(hat){p.AddLine(8,12,w-115,12);p.AddBezier(w-115,12,w-105,-4,w-42,-4,w-30,12);p.AddLine(w-30,12,w-8,12);}else{p.AddLine(8,2,n-10,2);p.AddLine(n-10,2,n-4,9);p.AddLine(n-4,9,n+14,9);p.AddLine(n+14,9,n+21,2);p.AddLine(n+21,2,w-8,2);}p.AddArc(w-16,hat?12:2,16,16,270,90);p.AddLine(w,h-18,w,h-14);p.AddArc(w-16,h-22,16,16,0,90);p.AddLine(w-8,h-6,n+21,h-6);p.AddLine(n+21,h-6,n+14,h);p.AddLine(n+14,h,n-4,h);p.AddLine(n-4,h,n-10,h-6);p.AddLine(n-10,h-6,8,h-6);p.AddArc(0,h-22,16,16,90,90);p.AddLine(0,h-14,0,hat?20:10);p.AddArc(0,hat?12:2,16,16,180,90);p.CloseFigure();return p;}
}
public class GlassButton:Button {
 bool hover,pressed;public GlassButton(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);FlatStyle=FlatStyle.Flat;FlatAppearance.BorderSize=0;Cursor=Cursors.Hand;MinimumSize=new Size(26,26);}
 protected override void OnResize(EventArgs e){base.OnResize(e);GlassDesign.RoundControl(this);}
 protected override void OnMouseEnter(EventArgs e){hover=true;Invalidate();base.OnMouseEnter(e);}protected override void OnMouseLeave(EventArgs e){hover=pressed=false;Invalidate();base.OnMouseLeave(e);}protected override void OnMouseDown(MouseEventArgs e){pressed=true;Invalidate();base.OnMouseDown(e);}protected override void OnMouseUp(MouseEventArgs e){pressed=false;Invalidate();base.OnMouseUp(e);}
 protected override void OnPaint(PaintEventArgs e){var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;using(var p=GlassDesign.Round(new RectangleF(1,1,Width-3,Height-3),12)){using(var b=new LinearGradientBrush(ClientRectangle,Color.FromArgb(hover?75:48,FutureTheme.Cyan),Color.FromArgb(pressed?95:12,FutureTheme.Purple),90f)){g.Clear(BackColor);g.FillPath(b,p);}using(var edge=new Pen(Color.FromArgb(hover?160:75,FutureTheme.Cyan)))g.DrawPath(edge,p);using(var shine=new Pen(Color.FromArgb(45,Color.White)))g.DrawArc(shine,4,3,Width-9,Math.Max(12,Height-12),192,155);}var r=ClientRectangle;r.Inflate(-6,-3);TextRenderer.DrawText(g,Text,Font,r,Enabled?ForeColor:FutureTheme.Muted,TextFormatFlags.NoPrefix|TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.WordBreak|(RightToLeft==RightToLeft.Yes?TextFormatFlags.RightToLeft:0));if(Focused)using(var pen=new Pen(FutureTheme.Cyan){DashStyle=DashStyle.Dot})g.DrawRectangle(pen,6,6,Width-13,Height-13);}
}
public class PuzzleButton:GlassButton {
 bool reporter,boolean;public bool Reporter{get{return reporter;}set{reporter=value;UpdateShape();}}public bool Boolean{get{return boolean;}set{boolean=value;UpdateShape();}}protected override void OnResize(EventArgs e){base.OnResize(e);UpdateShape();}GraphicsPath Shape(){return Boolean?GlassDesign.Hex(Width,Height):GlassDesign.Stack(Width,Height,false,Reporter);}void UpdateShape(){if(Width<2||Height<2)return;using(var p=Shape()){var old=Region;Region=new Region(p);if(old!=null)old.Dispose();}}
 protected override void OnPaint(PaintEventArgs e){var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;g.Clear(BackColor);using(var p=Shape())using(var pen=new Pen(Color.FromArgb(120,Color.White)))g.DrawPath(pen,p);var r=ClientRectangle;r.Inflate(-9,-10);TextRenderer.DrawText(g,Text,Font,r,Color.White,TextFormatFlags.NoPrefix|TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.WordBreak|TextFormatFlags.RightToLeft);}
}
public class GlassToolStripRenderer:ToolStripProfessionalRenderer {
 public GlassToolStripRenderer(ProfessionalColorTable colors):base(colors){}
 void Pill(ToolStripItemRenderEventArgs e){if(e.Item.Width<4||e.Item.Height<4)return;var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;using(var p=GlassDesign.Round(new RectangleF(2,2,e.Item.Width-4,e.Item.Height-4),12)){using(var tint=new LinearGradientBrush(new Rectangle(0,0,e.Item.Width,e.Item.Height),Color.FromArgb(e.Item.Selected?75:24,FutureTheme.Cyan),Color.FromArgb(12,FutureTheme.Purple),90f))g.FillPath(tint,p);using(var edge=new Pen(Color.FromArgb(e.Item.Selected?155:45,FutureTheme.Cyan)))g.DrawPath(edge,p);}}
 protected override void OnRenderButtonBackground(ToolStripItemRenderEventArgs e){Pill(e);}
 protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e){if(e.Item.Selected||e.Item.Pressed)Pill(e);}
}
}
